﻿Imports System.IO

Public Class MainForm

    Dim g_comstatus As Boolean
    Dim g_netindex As Integer
    Dim g_led, g_rgb As Integer
    Dim g_di, g_do, g_motorstat As Integer
    Dim g_encpos As Long
    Dim g_encvel As Double
    Dim g_tarpos As Long
    Dim g_tarvel As Double
    Dim angleval As Double = 0
    Dim hexstr As String
    Dim delay_tick As Integer
    Dim ArdComStat As Boolean
    Dim ArdComTi As Integer
    Dim ArdComTmax As Integer
    Dim DIDisplay(8) As PictureBox
    Dim DODisplay(3) As PictureBox
    Dim RGBDisplay(3) As PictureBox


    Private Sub SA1RunBtn_Click(sender As Object, e As EventArgs)
        TITAN_SerialCom.Instance.netid = 1
        TITAN_SerialCom.Instance.SA_COMMAND = 1
    End Sub

    Private Sub MainForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim documentsPath As String = Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments) + "\TITAN-SVX-V3"
        If Not Directory.Exists(documentsPath) Then
            Directory.CreateDirectory(documentsPath)
        End If
        Dim portfile As String = documentsPath + "\TITANSampleSettings.txt"

        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter(portfile, False)
        file.WriteLine(COMPort.Text)
        file.WriteLine(StartID.SelectedIndex.ToString)
        file.WriteLine(TextBox_TargetSpeed.Text)
        file.WriteLine(TextBox_TargetAccel.Text)
        file.WriteLine(TextBox_TargetDecel.Text)
        file.WriteLine(TextBox_TargetJerk.Text)
        file.WriteLine(TextBox_TargetPosition1.Text)
        file.WriteLine(TextBox_TargetPosition2.Text)
        file.WriteLine(IPAddress.Text)
        file.Close()
    End Sub
    Private Sub SA1StopBtn_Click(sender As Object, e As EventArgs)
        TITAN_SerialCom.Instance.netid = 1
        TITAN_SerialCom.Instance.SA_COMMAND = 2
    End Sub

    Private Sub CloseCom()
        TITAN_SerialCom.Instance.Disconnect()
        EthernetConnectBtn.Text = "Connect"
        EthernetConnectBtn.BackColor = Color.Cyan
        EthernetConnectBtn.Enabled = True
        COMConnectBtn.Text = "Connect"
        COMConnectBtn.BackColor = Color.Lime
        COMConnectBtn.Enabled = True
        g_comstatus = False
        Button_Enable.Enabled = False
        CommandTextbox.Enabled = False
        Button_Disable.Enabled = False
        Button_ClearFault.Enabled = False
        Button_X_Move1.Enabled = False
        Button_X_Move2.Enabled = False
        ReadVar.Enabled = False
        WriteVar.Enabled = False
        ButtonSetPos.Enabled = False
        Button_JogMinus.Enabled = False
        Button_JogPlus.Enabled = False
        JogVelBar.Enabled = False
        JogVelBar.Value = 100
        Button_Home.Enabled = False
        Button_STOPX.Enabled = False
        Button_ZeroVel.Enabled = False

        Button_Gosub.Enabled = False
        Button_Run0.Enabled = False
        Button_Run1.Enabled = False
        Button_Run2.Enabled = False
        Button_Stop0.Enabled = False
        Button_Stop1.Enabled = False
        Button_Stop2.Enabled = False

        Button_STOPX.BackColor = Color.Silver
        LEDStat1.Enabled = False
        LEDStat1.BackColor = Color.Silver
        For i = 0 To 2
            RGBDisplay(i).Enabled = False
            RGBDisplay(i).BackColor = Color.Silver
            DODisplay(i).Enabled = False
            DODisplay(i).BackColor = Color.Silver
        Next
        For i = 0 To 7
            DIDisplay(i).Enabled = False
            DIDisplay(i).BackColor = Color.Silver
        Next

    End Sub

    Private Sub Button_Enable_C_Click(sender As Object, e As EventArgs) Handles Button_Enable.Click
        If TITAN_SerialCom.Instance.IsConnected Then
            Dim ret As Integer
            ret = TITAN_SerialCom.Instance.SVON()
            If (ret <> 1) Then
                MsgBox("SVON Error: " + ret.ToString)
            End If
        End If
    End Sub

    Private Sub Button_JogPlus_MouseDown_1(sender As Object, e As MouseEventArgs) Handles Button_JogPlus.MouseDown
        Try
            If TITAN_SerialCom.Instance.IsConnected Then
                Dim speed, accel, decel, jerk As Double
                Dim ret As Integer
                Dim scurve As Integer = 0
                If (ScurveRadio.Checked) Then
                    scurve = 1
                End If
                speed = Double.Parse(TextBox_TargetSpeed.Text)
                accel = Double.Parse(TextBox_TargetAccel.Text)
                decel = Double.Parse(TextBox_TargetDecel.Text)
                jerk = Double.Parse(TextBox_TargetJerk.Text)
                ret = TITAN_SerialCom.Instance.JOGXP(speed, accel, decel, jerk, scurve)
                If (ret <> 1) Then
                    ret = TITAN_SerialCom.Instance.JOGXP(0, accel, decel, jerk, scurve)
                    MsgBox("Jog Plus Error: " + ret.ToString)
                End If
            End If
        Catch ex As Exception
            MsgBox("Move Exception Error")
        End Try
    End Sub

    Private Sub Button_JogMinus_MouseDown_1(sender As Object, e As MouseEventArgs) Handles Button_JogMinus.MouseDown
        Try
            If TITAN_SerialCom.Instance.IsConnected Then
                Dim speed, accel, decel, jerk As Double
                Dim ret As Integer
                Dim scurve As Integer = 0
                If (ScurveRadio.Checked) Then
                    scurve = 1
                End If
                speed = Double.Parse(TextBox_TargetSpeed.Text)
                accel = Double.Parse(TextBox_TargetAccel.Text)
                decel = Double.Parse(TextBox_TargetDecel.Text)
                jerk = Double.Parse(TextBox_TargetJerk.Text)
                ret = TITAN_SerialCom.Instance.JOGXN(speed, accel, decel, jerk, scurve)
                If (ret <> 1) Then
                    ret = TITAN_SerialCom.Instance.JOGXP(0, accel, decel, jerk, scurve)
                    MsgBox("Jog Minus Error: " + ret.ToString)
                End If
            End If
        Catch ex As Exception
            MsgBox("Move Exception Error")
        End Try
    End Sub

    Private Sub Button_JogPlus_MouseUp_1(sender As Object, e As MouseEventArgs) Handles Button_JogPlus.MouseUp
        Call Button_ZeroVel_Click(sender, e)
    End Sub

    Private Sub Button_JogMinus_MouseUp_1(sender As Object, e As MouseEventArgs) Handles Button_JogMinus.MouseUp
        Call Button_ZeroVel_Click(sender, e)
    End Sub

    Private Sub Button_STOPX1_Click(sender As Object, e As EventArgs) Handles Button_STOPX.Click
        Try
            If TITAN_SerialCom.Instance.IsConnected Then
                Dim accel, decel As Double
                accel = Double.Parse(TextBox_TargetAccel.Text)
                decel = Double.Parse(TextBox_TargetDecel.Text)
                TITAN_SerialCom.Instance.STOPX(0, accel, decel)
                JogVelBar.Value = 100
            End If
        Catch ex As Exception
            MsgBox("Move Exception Error")
        End Try

    End Sub

    Private Sub ScurveRadio_CheckedChanged(sender As Object, e As EventArgs) Handles ScurveRadio.CheckedChanged
        If TITAN_SerialCom.Instance.IsConnected Then
            TITAN_SerialCom.Instance.SCURVE()
        End If
    End Sub

    Private Sub TrapRadio_CheckedChanged(sender As Object, e As EventArgs) Handles TrapRadio.CheckedChanged
        If TITAN_SerialCom.Instance.IsConnected Then
            TITAN_SerialCom.Instance.TRAP()
        End If
    End Sub

    Sub TriggerDO(bit As Integer)
        If TITAN_SerialCom.Instance.IsConnected Then
            If (DODisplay(bit).BackColor = Color.Gray) Then
                TITAN_SerialCom.Instance.DOBit(bit, 1)
            Else
                TITAN_SerialCom.Instance.DOBit(bit, 0)
            End If
        End If
    End Sub
    Private Sub DO11_DoubleClick(sender As Object, e As EventArgs) Handles DO11.DoubleClick
        Call TriggerDO(0)
    End Sub

    Private Sub DO12_DoubleClick(sender As Object, e As EventArgs) Handles DO12.DoubleClick
        Call TriggerDO(1)
    End Sub

    Private Sub DO13_DoubleClick(sender As Object, e As EventArgs) Handles DO13.DoubleClick
        Call TriggerDO(2)
    End Sub

    Private Sub LEDStat1_DoubleClick(sender As Object, e As EventArgs) Handles LEDStat1.DoubleClick
        If TITAN_SerialCom.Instance.IsConnected Then
            If (LEDStat1.BackColor = Color.Gray) Then
                TITAN_SerialCom.Instance.LED(1)
            Else
                TITAN_SerialCom.Instance.LED(0)
            End If
        End If
    End Sub
    Private Function toggleRGB(bit As Integer) As Integer
        Dim currentStat As Integer
        If (RLed1.BackColor = Color.Red) Then
            currentStat = currentStat Or 1
        End If
        If (GLed1.BackColor = Color.Green) Then
            currentStat = currentStat Or 2
        End If
        If (BLed1.BackColor = Color.Blue) Then
            currentStat = currentStat Or 4
        End If

        If (RGBDisplay(bit).BackColor = Color.Gray) Then
            currentStat = currentStat Or (1 << bit)
        Else
            currentStat = currentStat And (7 And Not (1 << bit))
        End If
        TITAN_SerialCom.Instance.RGB(currentStat)
        Return currentStat
    End Function
    Private Sub RLed1_DoubleClick(sender As Object, e As EventArgs) Handles RLed1.DoubleClick
        If TITAN_SerialCom.Instance.IsConnected Then
            toggleRGB(0)
        End If
    End Sub

    Private Sub GLed1_DoubleClick(sender As Object, e As EventArgs) Handles GLed1.DoubleClick
        If TITAN_SerialCom.Instance.IsConnected Then
            toggleRGB(1)
        End If
    End Sub

    Private Sub BLed1_DoubleClick(sender As Object, e As EventArgs) Handles BLed1.DoubleClick
        If TITAN_SerialCom.Instance.IsConnected Then
            toggleRGB(2)
        End If
    End Sub

    Private Sub Button_Disable_C_Click(sender As Object, e As EventArgs) Handles Button_Disable.Click
        If TITAN_SerialCom.Instance.IsConnected Then
            Dim ret As Integer
            ret = TITAN_SerialCom.Instance.SVOFF()
            If (ret <> 1) Then
                MsgBox("SVOFF Error: " + ret.ToString)
            End If
        End If
    End Sub

    Private Sub DoHome_Click(sender As Object, e As EventArgs) Handles Button_Home.Click
        Try
            If TITAN_SerialCom.Instance.IsConnected Then
                Dim ret, hmode As Integer
                Dim speed, accel, decel, jerk As Double
                Dim scurve As Integer = 0
                If (ScurveRadio.Checked) Then
                    scurve = 1
                End If
                hmode = ComboBox_HomeMode.SelectedIndex
                speed = Double.Parse(TextBox_TargetSpeed.Text)
                accel = Double.Parse(TextBox_TargetAccel.Text)
                decel = Double.Parse(TextBox_TargetDecel.Text)
                jerk = Double.Parse(TextBox_TargetJerk.Text)
                ret = TITAN_SerialCom.Instance.HOMEX(hmode, speed, accel, decel, jerk, scurve)
                If (ret <> 1) Then
                    MsgBox("Jog Plus Error: " + ret.ToString)
                End If
            End If
        Catch ex As Exception
            MsgBox("Move Exception Error")
        End Try
    End Sub

    Private Sub Button_ClearFault_C_Click(sender As Object, e As EventArgs) Handles Button_ClearFault.Click
        If TITAN_SerialCom.Instance.IsConnected Then
            Dim ret As Integer
            ret = TITAN_SerialCom.Instance.ECLEARX()
            If (ret <> 1) Then
                MsgBox("ECLEAR Error: " + ret.ToString)
            End If
        End If
    End Sub


    Private Sub Button_MoveTest1_Click(sender As Object, e As EventArgs) Handles Button_X_Move1.Click
        If TITAN_SerialCom.Instance.IsConnected Then
            Try
                Dim speed, accel, decel, jerk As Double
                Dim target As Long
                Dim ret As Integer
                Dim scurve As Integer = 0
                If (ScurveRadio.Checked) Then
                    scurve = 1
                End If
                target = Long.Parse(TextBox_TargetPosition1.Text)
                speed = Double.Parse(TextBox_TargetSpeed.Text)
                accel = Double.Parse(TextBox_TargetAccel.Text)
                decel = Double.Parse(TextBox_TargetDecel.Text)
                jerk = Double.Parse(TextBox_TargetJerk.Text)
                ret = TITAN_SerialCom.Instance.X(target, speed, accel, decel, jerk, scurve)
                If (ret <> 1) Then
                    MsgBox("Move to Target Error: " + ret.ToString)
                End If
            Catch ex As Exception
                MsgBox("Move Exception Error")
            End Try
        End If
    End Sub

    Private Sub JogVelBar_Scroll(sender As Object, e As EventArgs) Handles JogVelBar.Scroll
        If TITAN_SerialCom.Instance.IsConnected Then
            Try
                Dim speed, accel, decel, jerk As Double
                Dim ret As Integer
                Dim scurve As Integer = 0
                If (ScurveRadio.Checked) Then
                    scurve = 1
                End If
                speed = Double.Parse(TextBox_TargetSpeed.Text)
                speed = speed * (JogVelBar.Value - 100) / 100
                accel = Double.Parse(TextBox_TargetAccel.Text)
                decel = Double.Parse(TextBox_TargetDecel.Text)
                jerk = Double.Parse(TextBox_TargetJerk.Text)
                ret = TITAN_SerialCom.Instance.JOGXP(speed, accel, decel, jerk, scurve)
                If (ret <> 1) Then
                    ret = TITAN_SerialCom.Instance.JOGXP(0, accel, decel, jerk, scurve)
                    JogVelBar.Value = 100
                    MsgBox("Jog Plus Error: " + ret.ToString)
                End If
            Catch ex As Exception
                MsgBox("Move Exception Error")
            End Try
        End If
    End Sub

    Private Sub Button_ZeroVel_Click(sender As Object, e As EventArgs) Handles Button_ZeroVel.Click
        Try
            Dim speed, accel, decel, jerk As Double
            Dim ret As Integer
            Dim scurve As Integer = 0
            If (ScurveRadio.Checked) Then
                scurve = 1
            End If
            speed = Double.Parse(TextBox_TargetSpeed.Text)
            accel = Double.Parse(TextBox_TargetAccel.Text)
            decel = Double.Parse(TextBox_TargetDecel.Text)
            jerk = Double.Parse(TextBox_TargetJerk.Text)
            ret = TITAN_SerialCom.Instance.JOGXP(0, accel, decel, jerk, scurve)
            JogVelBar.Value = 100
        Catch ex As Exception
            MsgBox("Move Exception Error")
        End Try
    End Sub
    Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl1.SelectedIndexChanged
        Call Button_STOPX1_Click(sender, e)
    End Sub

    Private Sub Button_X_Move2_Click(sender As Object, e As EventArgs) Handles Button_X_Move2.Click
        Try
            If TITAN_SerialCom.Instance.IsConnected Then
                Dim speed, accel, decel, jerk As Double
                Dim target As Long
                Dim ret As Integer
                Dim scurve As Integer = 0
                If (ScurveRadio.Checked) Then
                    scurve = 1
                End If
                target = Long.Parse(TextBox_TargetPosition2.Text)
                speed = Double.Parse(TextBox_TargetSpeed.Text)
                accel = Double.Parse(TextBox_TargetAccel.Text)
                decel = Double.Parse(TextBox_TargetDecel.Text)
                jerk = Double.Parse(TextBox_TargetJerk.Text)
                ret = TITAN_SerialCom.Instance.X(target, speed, accel, decel, jerk, scurve)
                If (ret <> 1) Then
                    MsgBox("Move to Target Error: " + ret.ToString)
                End If
            End If
        Catch ex As Exception
            MsgBox("Move Exception Error")
        End Try

    End Sub

    Private Sub ButtonSetPos_Click(sender As Object, e As EventArgs) Handles ButtonSetPos.Click
        If TITAN_SerialCom.Instance.IsConnected Then
            Dim target As Long
            target = Long.Parse(TextBox_TargetPosition2.Text)
            TITAN_SerialCom.Instance.EX = target
        End If
    End Sub

    Private Sub GosubBtn_Click(sender As Object, e As EventArgs) Handles Button_Gosub.Click
        If TITAN_SerialCom.Instance.IsConnected Then
            Dim subnumber As Integer
            Dim stat As Integer
            subnumber = Integer.Parse(SubNumberList.SelectedItem)
            TITAN_SerialCom.Instance.GOSUBCMD(subnumber, stat)
            If (stat <> 1) Then
                MsgBox("GOSUB Command Error.")
            End If
        End If
    End Sub
    Private Sub SARun(pn As Integer)
        If TITAN_SerialCom.Instance.IsConnected Then
            Dim cn As Integer = 40
            If (pn = 0) Then
                cn = 40
            ElseIf (pn = 1) Then
                cn = 41
            ElseIf (pn = 2) Then
                cn = 42
            End If
            TITAN_SerialCom.Instance.SA_COMMAND = cn
            Dim reply_str As String
            reply_str = TITAN_SerialCom.Instance.SAY
            If (reply_str = "3") Then
                MsgBox("Cannot run program.  Program is empty.")
                Exit Sub
            ElseIf (reply_str = "2") Then
                MsgBox("Cannot run program.  Program is in error state.")
                Exit Sub
            ElseIf (reply_str = "1") Then
                MsgBox("Cannot run program.  Program is not in idle.")
                Exit Sub
            End If
        End If
    End Sub
    Private Sub SAStop(pn As Integer)
        If TITAN_SerialCom.Instance.IsConnected Then
            Dim cn As Integer = 40
            If (pn = 0) Then
                cn = 43
            ElseIf (pn = 1) Then
                cn = 44
            ElseIf (pn = 2) Then
                cn = 45
            End If
            TITAN_SerialCom.Instance.SA_COMMAND = cn
        End If
    End Sub
    Private Sub Run0_Click(sender As Object, e As EventArgs) Handles Button_Run0.Click
        SARun(0)
    End Sub
    Private Sub Run1_Click(sender As Object, e As EventArgs) Handles Button_Run1.Click
        SARun(1)
    End Sub
    Private Sub Run2_Click(sender As Object, e As EventArgs) Handles Button_Run2.Click
        SARun(2)
    End Sub

    Private Sub Stop0_Click(sender As Object, e As EventArgs) Handles Button_Stop0.Click
        SAStop(0)
    End Sub
    Private Sub Stop1_Click(sender As Object, e As EventArgs) Handles Button_Stop1.Click
        SAStop(1)
    End Sub
    Private Sub Stop2_Click(sender As Object, e As EventArgs) Handles Button_Stop2.Click
        SAStop(2)
    End Sub
    Private Sub EthernetConnectBtn_Click(sender As Object, e As EventArgs) Handles EthernetConnectBtn.Click

        If (TITAN_SerialCom.Instance.IsConnected) Then
            Call CloseCom()
            Exit Sub
        End If

        Try
            If My.Computer.Network.Ping(IPAddress.Text) Then
            Else
                MessageBox.Show("TITAN is not responding to the initial socket communication check." + vbCrLf + vbCrLf + "Please check the IP address and the connection.", "Communication Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If
        Catch ex As Exception
            MessageBox.Show("Invalid IP Address!", "Communication Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End Try

        TITAN_SerialCom.Instance.comType = DEF_TITAN.COM_ETHERNET
        TITAN_SerialCom.Instance.ComStatus = False

        TITAN_SerialCom.Instance.Connect(IPAddress.Text, "100")

        If TITAN_SerialCom.Instance.IsConnected Then

            g_netindex = StartID.SelectedIndex + 1
            TITAN_SerialCom.Instance.netid = g_netindex

            If TITAN_SerialCom.Instance.IsConnected Then
                g_netindex = StartID.SelectedIndex + 1
                TITAN_SerialCom.Instance.netid = g_netindex
                If TITAN_SerialCom.Instance.IsCommunicating Then
                    g_comstatus = True
                    COMConnectBtn.Text = "NA"
                    COMConnectBtn.BackColor = Color.Gray
                    COMConnectBtn.Enabled = False
                    EthernetConnectBtn.Text = "Disconnect"
                    EthernetConnectBtn.BackColor = Color.Magenta
                    Button_Gosub.Enabled = True
                    Button_Run0.Enabled = True
                    Button_Run1.Enabled = True
                    Button_Run2.Enabled = True
                    Button_Stop0.Enabled = True
                    Button_Stop1.Enabled = True
                    Button_Stop2.Enabled = True
                    Button_Enable.Enabled = True
                    CommandTextbox.Enabled = True
                    Button_Disable.Enabled = True
                    Button_ClearFault.Enabled = True
                    Button_X_Move1.Enabled = True
                    Button_X_Move2.Enabled = True
                    ReadVar.Enabled = True
                    WriteVar.Enabled = True
                    ButtonSetPos.Enabled = True
                    Button_JogMinus.Enabled = True
                    Button_JogPlus.Enabled = True
                    JogVelBar.Enabled = True
                    JogVelBar.Value = 100
                    Button_Home.Enabled = True
                    Button_STOPX.Enabled = True
                    Button_ZeroVel.Enabled = True
                    Button_STOPX.BackColor = Color.Red
                    LEDStat1.Enabled = True
                    For i = 0 To 2
                        RGBDisplay(i).Enabled = True
                        DODisplay(i).Enabled = True
                    Next
                    For i = 0 To 7
                        DIDisplay(i).Enabled = True
                    Next
                Else
                    g_comstatus = False
                End If
            Else
                g_comstatus = False
                Dim str As String
                str = "Ethernet Communication Port not available to open!"
                MsgBox(str, MessageBoxIcon.Exclamation, "Communication Status")
            End If
        Else
            MsgBox("Cannot Connect to IP Address: " + IPAddress.Text)
        End If
        Exit Sub

    End Sub

    Private Sub ReadVar_Click(sender As Object, e As EventArgs) Handles ReadVar.Click
        Try
            If TITAN_SerialCom.Instance.IsConnected Then
                Dim ret, vid As Integer
                Dim vval As Long
                vid = VarIDList.SelectedIndex + 1
                ret = TITAN_SerialCom.Instance.READ_VAR(vid, vval)
                If (ret <> True) Then
                    MsgBox("Var Read Error: " + ret.ToString)
                End If
                VarValue.Text = vval.ToString
            End If
        Catch ex As Exception
            MsgBox("Read Variable Exception Error!")
        End Try
    End Sub

    Private Sub WriteVar_Click(sender As Object, e As EventArgs) Handles WriteVar.Click
        Try
            If TITAN_SerialCom.Instance.IsConnected Then
                Dim ret, vid As Integer
                Dim vval As Long

                vval = Long.Parse(VarValue.Text)
                vid = VarIDList.SelectedIndex + 1
                ret = TITAN_SerialCom.Instance.WRITE_VAR(vid, vval)
                If (ret <> True) Then
                    MsgBox("Var Write Error: " + ret.ToString)
                End If
                VarValue.Text = vval.ToString
            End If
        Catch ex As Exception
            MsgBox("WRITE Variable Exception Error!")
        End Try

    End Sub

    Private Sub CommandTextbox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CommandTextbox.KeyPress
        Try
            If e.KeyChar = ChrW(Keys.Return) Then
                Dim cmdStr, replyStr As String
                replyStr = ""
                cmdStr = CommandTextbox.Text
                If (TITAN_SerialCom.Instance.CommandReply(cmdStr, replyStr) = True) Then
                    ReplyTextbox.Text = replyStr
                Else
                    ReplyTextbox.Text = "<NOCOM>"
                End If
                CommandTextbox.Text = ""
                CommandTextbox.Focus()
            End If
        Catch ex As Exception
            MsgBox("Command and Reply Exception Error!")
        End Try
    End Sub

    Private Sub COMConnectBtn_Click(sender As Object, e As EventArgs) Handles COMConnectBtn.Click
        Dim comPortStr As String = ""

        comPortStr = COMPort.Text
        If (comPortStr = "") Then
            comPortStr = "COM5"
        End If

        g_netindex = StartID.SelectedIndex + 1

        If (TITAN_SerialCom.Instance.IsConnected) Then
            Call CloseCom()
            Exit Sub
        End If
        COMConnectBtn.Text = "Connect"
        COMConnectBtn.BackColor = Color.Lime
        Dim timeout As Integer
        timeout = 100
        TITAN_SerialCom.Instance.comType = DEF_TITAN.COM_SERIAL
        TITAN_SerialCom.Instance.Connect(comPortStr, timeout.ToString)
        If TITAN_SerialCom.Instance.IsConnected Then
            g_netindex = StartID.SelectedIndex + 1
            TITAN_SerialCom.Instance.netid = g_netindex
            If TITAN_SerialCom.Instance.IsCommunicating Then
                g_comstatus = True
                EthernetConnectBtn.Text = "NA"
                EthernetConnectBtn.BackColor = Color.Gray
                EthernetConnectBtn.Enabled = False
                COMConnectBtn.Text = "Disconnect"
                COMConnectBtn.BackColor = Color.Magenta
                Button_Gosub.Enabled = True
                Button_Run0.Enabled = True
                Button_Run1.Enabled = True
                Button_Run2.Enabled = True
                Button_Stop0.Enabled = True
                Button_Stop1.Enabled = True
                Button_Stop2.Enabled = True
                Button_Enable.Enabled = True
                CommandTextbox.Enabled = True
                Button_Disable.Enabled = True
                Button_ClearFault.Enabled = True
                Button_X_Move1.Enabled = True
                Button_X_Move2.Enabled = True
                ReadVar.Enabled = True
                WriteVar.Enabled = True
                ButtonSetPos.Enabled = True
                Button_JogMinus.Enabled = True
                Button_JogPlus.Enabled = True
                JogVelBar.Enabled = True
                JogVelBar.Value = 100
                Button_Home.Enabled = True
                Button_STOPX.Enabled = True
                Button_ZeroVel.Enabled = True
                Button_STOPX.BackColor = Color.Red
                LEDStat1.Enabled = True
                For i = 0 To 2
                    RGBDisplay(i).Enabled = True
                    DODisplay(i).Enabled = True
                Next
                For i = 0 To 7
                    DIDisplay(i).Enabled = True
                Next
            Else
                g_comstatus = False
            End If
        Else
            g_comstatus = False
            Dim str As String
            str = "Communication Port " + comPortStr + " is not available to open."
            MsgBox(str, MessageBoxIcon.Exclamation, "Communication Status")
        End If
    End Sub

    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        VarIDList.SelectedIndex = 0
        SubNumberList.SelectedIndex = 0

        DIDisplay(0) = DI11
        DIDisplay(1) = DI12
        DIDisplay(2) = DI13
        DIDisplay(3) = DI14
        DIDisplay(4) = DI15
        DIDisplay(5) = DI16
        DIDisplay(6) = DI17
        DIDisplay(7) = DI18

        DODisplay(0) = DO11
        DODisplay(1) = DO12
        DODisplay(2) = DO13

        RGBDisplay(0) = RLed1
        RGBDisplay(1) = GLed1
        RGBDisplay(2) = BLed1

        g_netindex = 1

        Dim comPortstr As String = "COM5"
        Dim startIDstr As String = "0"
        Dim ipAddressStr As String = "192.168.1.100"
        Dim startIDi As Integer
        Dim documentsPath As String = Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments) + "\TITAN-SVX-V3"
        If Not Directory.Exists(documentsPath) Then
            Directory.CreateDirectory(documentsPath)
        End If
        Dim portfile As String = documentsPath + "\TITANSampleSettings.txt"
        If My.Computer.FileSystem.FileExists(portfile) Then
            Dim fileReader As System.IO.StreamReader
            fileReader = My.Computer.FileSystem.OpenTextFileReader(portfile)
            comPortstr = fileReader.ReadLine()
            startIDstr = fileReader.ReadLine()
            TextBox_TargetSpeed.Text = fileReader.ReadLine()
            If (TextBox_TargetSpeed.Text = "") Then TextBox_TargetSpeed.Text = "100"
            TextBox_TargetAccel.Text = fileReader.ReadLine()
            If (TextBox_TargetAccel.Text = "") Then TextBox_TargetAccel.Text = "2000"
            TextBox_TargetDecel.Text = fileReader.ReadLine()
            If (TextBox_TargetDecel.Text = "") Then TextBox_TargetDecel.Text = "2000"
            TextBox_TargetJerk.Text = fileReader.ReadLine()
            If (TextBox_TargetJerk.Text = "") Then TextBox_TargetJerk.Text = "50000"
            TextBox_TargetPosition1.Text = fileReader.ReadLine()
            If (TextBox_TargetPosition1.Text = "") Then TextBox_TargetPosition1.Text = "1200"
            TextBox_TargetPosition2.Text = fileReader.ReadLine()
            If (TextBox_TargetPosition2.Text = "") Then TextBox_TargetPosition2.Text = "-1200"
            startIDi = Integer.Parse(startIDstr)
            ipAddressStr = fileReader.ReadLine()
            fileReader.Close()
            If (comPortstr = "") Then
                comPortstr = "COM5"
            End If
            If (startIDi < 0 Or startIDi > 23) Then
                startIDi = 0
            End If
            If (ipAddressStr = "") Then
                ipAddressStr = "192.168.1.100"
            End If
        End If
        COMPort.Text = comPortstr
        StartID.SelectedIndex = startIDi
        g_netindex = startIDi + 1
        ComboBox_HomeMode.SelectedIndex = 0
        IPAddress.Text = ipAddressStr
        Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If (g_comstatus = True) Then
            TITAN_SerialCom.Instance.netid = g_netindex
            If (TITAN_SerialCom.Instance.ALLSTATUS(g_di, g_do, g_motorstat, g_encpos, g_encvel, g_tarpos, g_tarvel, g_led, g_rgb) = False) Then
                g_comstatus = False
                MsgBox("Communication Error!")
                Call CloseCom()
                Exit Sub
            Else
                STAT1.Text = g_motorstat.ToString + vbCrLf
                If (g_motorstat And DEF_TITAN.ST_ENABLE) Then
                    STAT1.Text = STAT1.Text + "/ENA "
                Else
                    STAT1.Text = STAT1.Text + "/DIS "
                End If
                If (g_motorstat And DEF_TITAN.ST_IN_POSITION) Then
                    STAT1.Text = STAT1.Text + "/INP "
                End If
                If (g_motorstat And DEF_TITAN.ST_MOVING) Then
                    STAT1.Text = STAT1.Text + "/MOV "
                End If
                If (g_motorstat And DEF_TITAN.ST_FAULT) Then
                    STAT1.Text = STAT1.Text + "/FLT "
                End If
                If (g_motorstat And DEF_TITAN.ST_HOMING_COMP) Then
                    STAT1.Text = STAT1.Text + "/HM "
                End If

                EX1.Text = g_encpos.ToString
                VX1.Text = g_encvel.ToString("0.0")
                POSD1.Text = g_tarpos.ToString
                VPROF1.Text = g_tarvel.ToString("0.0")
                For i = 0 To 7
                    If (g_di And 1 << i) Then
                        If (DIDisplay(i).BackColor <> Color.Green) Then
                            DIDisplay(i).BackColor = Color.Green
                        End If
                    Else
                        If (DIDisplay(i).BackColor <> Color.Gray) Then
                            DIDisplay(i).BackColor = Color.Gray
                        End If
                    End If
                Next
                For i = 0 To 2
                    If (g_do And 1 << i) Then
                        If (DODisplay(i).BackColor <> Color.Red) Then
                            DODisplay(i).BackColor = Color.Red
                        End If
                    Else
                        If (DODisplay(i).BackColor <> Color.Gray) Then
                            DODisplay(i).BackColor = Color.Gray
                        End If
                    End If
                Next
                If (g_led = 0) Then
                    If LEDStat1.BackColor <> Color.Gray Then
                        LEDStat1.BackColor = Color.Gray
                    End If
                Else
                    If LEDStat1.BackColor <> Color.Blue Then
                        LEDStat1.BackColor = Color.Blue
                    End If
                End If
                If (g_rgb And 1) Then
                    If (RLed1.BackColor <> Color.Red) Then
                        RLed1.BackColor = Color.Red
                    End If
                Else
                    If (RLed1.BackColor <> Color.Gray) Then
                        RLed1.BackColor = Color.Gray
                    End If
                End If
                If (g_rgb And 2) Then
                    If (GLed1.BackColor <> Color.Green) Then
                        GLed1.BackColor = Color.Green
                    End If
                Else
                    If (GLed1.BackColor <> Color.Gray) Then
                        GLed1.BackColor = Color.Gray
                    End If
                End If
                If (g_rgb And 4) Then
                    If (BLed1.BackColor <> Color.Blue) Then
                        BLed1.BackColor = Color.Blue
                    End If
                Else
                    If (BLed1.BackColor <> Color.Gray) Then
                        BLed1.BackColor = Color.Gray
                    End If
                End If
            End If
        End If
    End Sub
End Class
