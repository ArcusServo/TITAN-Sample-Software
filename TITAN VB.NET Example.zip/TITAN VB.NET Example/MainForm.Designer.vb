﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.COMConnectBtn = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ID1GroupBox = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.VPROF1 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.POSD1 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.STAT1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.VX1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.EX1 = New System.Windows.Forms.TextBox()
        Me.COMPort = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.StartID = New System.Windows.Forms.ComboBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.BLed1 = New System.Windows.Forms.PictureBox()
        Me.GLed1 = New System.Windows.Forms.PictureBox()
        Me.RLed1 = New System.Windows.Forms.PictureBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.LEDStat1 = New System.Windows.Forms.PictureBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.DO13 = New System.Windows.Forms.PictureBox()
        Me.DO12 = New System.Windows.Forms.PictureBox()
        Me.DO11 = New System.Windows.Forms.PictureBox()
        Me.DI18 = New System.Windows.Forms.PictureBox()
        Me.DI17 = New System.Windows.Forms.PictureBox()
        Me.DI16 = New System.Windows.Forms.PictureBox()
        Me.DI15 = New System.Windows.Forms.PictureBox()
        Me.DI14 = New System.Windows.Forms.PictureBox()
        Me.DI13 = New System.Windows.Forms.PictureBox()
        Me.DI12 = New System.Windows.Forms.PictureBox()
        Me.DI11 = New System.Windows.Forms.PictureBox()
        Me.TextBox_TargetDecel = New System.Windows.Forms.TextBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.TextBox_TargetSpeed = New System.Windows.Forms.TextBox()
        Me.TextBox_TargetAccel = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.ComboBox_HomeMode = New System.Windows.Forms.ComboBox()
        Me.Button_JogPlus = New System.Windows.Forms.Button()
        Me.Button_JogMinus = New System.Windows.Forms.Button()
        Me.Button_Home = New System.Windows.Forms.Button()
        Me.ScurveRadio = New System.Windows.Forms.RadioButton()
        Me.TrapRadio = New System.Windows.Forms.RadioButton()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Button_X_Move1 = New System.Windows.Forms.Button()
        Me.TextBox_TargetPosition1 = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Servo = New System.Windows.Forms.TabPage()
        Me.Button_ClearFault = New System.Windows.Forms.Button()
        Me.Button_Enable = New System.Windows.Forms.Button()
        Me.Button_Disable = New System.Windows.Forms.Button()
        Me.TargetMotion = New System.Windows.Forms.TabPage()
        Me.ButtonSetPos = New System.Windows.Forms.Button()
        Me.Button_X_Move2 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox_TargetPosition2 = New System.Windows.Forms.TextBox()
        Me.JogMotion = New System.Windows.Forms.TabPage()
        Me.Button_ZeroVel = New System.Windows.Forms.Button()
        Me.JogVelBar = New System.Windows.Forms.TrackBar()
        Me.HomeMotion = New System.Windows.Forms.TabPage()
        Me.SA = New System.Windows.Forms.TabPage()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.SubNumberList = New System.Windows.Forms.ComboBox()
        Me.Button_Gosub = New System.Windows.Forms.Button()
        Me.Button_Stop2 = New System.Windows.Forms.Button()
        Me.Button_Stop1 = New System.Windows.Forms.Button()
        Me.Button_Run0 = New System.Windows.Forms.Button()
        Me.Button_Stop0 = New System.Windows.Forms.Button()
        Me.Button_Run1 = New System.Windows.Forms.Button()
        Me.Button_Run2 = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox_TargetJerk = New System.Windows.Forms.TextBox()
        Me.Button_STOPX = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.EthernetConnectBtn = New System.Windows.Forms.Button()
        Me.IPAddress = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.WriteVar = New System.Windows.Forms.Button()
        Me.ReadVar = New System.Windows.Forms.Button()
        Me.VarValue = New System.Windows.Forms.TextBox()
        Me.VarIDList = New System.Windows.Forms.ComboBox()
        Me.CommandTextbox = New System.Windows.Forms.TextBox()
        Me.ReplyTextbox = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.ID1GroupBox.SuspendLayout()
        CType(Me.BLed1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GLed1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RLed1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LEDStat1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DO13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DO12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DO11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DI18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DI17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DI16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DI15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DI14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DI13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DI12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DI11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.Servo.SuspendLayout()
        Me.TargetMotion.SuspendLayout()
        Me.JogMotion.SuspendLayout()
        CType(Me.JogVelBar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.HomeMotion.SuspendLayout()
        Me.SA.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'COMConnectBtn
        '
        Me.COMConnectBtn.BackColor = System.Drawing.Color.Lime
        Me.COMConnectBtn.Location = New System.Drawing.Point(71, 19)
        Me.COMConnectBtn.Name = "COMConnectBtn"
        Me.COMConnectBtn.Size = New System.Drawing.Size(75, 48)
        Me.COMConnectBtn.TabIndex = 1
        Me.COMConnectBtn.Text = "Connect"
        Me.COMConnectBtn.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 50
        '
        'ID1GroupBox
        '
        Me.ID1GroupBox.Controls.Add(Me.Label8)
        Me.ID1GroupBox.Controls.Add(Me.VPROF1)
        Me.ID1GroupBox.Controls.Add(Me.Label7)
        Me.ID1GroupBox.Controls.Add(Me.POSD1)
        Me.ID1GroupBox.Controls.Add(Me.Label14)
        Me.ID1GroupBox.Controls.Add(Me.STAT1)
        Me.ID1GroupBox.Controls.Add(Me.Label3)
        Me.ID1GroupBox.Controls.Add(Me.VX1)
        Me.ID1GroupBox.Controls.Add(Me.Label2)
        Me.ID1GroupBox.Controls.Add(Me.EX1)
        Me.ID1GroupBox.Location = New System.Drawing.Point(31, 97)
        Me.ID1GroupBox.Name = "ID1GroupBox"
        Me.ID1GroupBox.Size = New System.Drawing.Size(251, 115)
        Me.ID1GroupBox.TabIndex = 40
        Me.ID1GroupBox.TabStop = False
        Me.ID1GroupBox.Text = "Status:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 90)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 14)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Target Speed:"
        '
        'VPROF1
        '
        Me.VPROF1.Location = New System.Drawing.Point(86, 87)
        Me.VPROF1.Name = "VPROF1"
        Me.VPROF1.ReadOnly = True
        Me.VPROF1.Size = New System.Drawing.Size(73, 20)
        Me.VPROF1.TabIndex = 8
        Me.VPROF1.Text = "0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(19, 44)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(61, 14)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Target Pos:"
        '
        'POSD1
        '
        Me.POSD1.Location = New System.Drawing.Point(86, 41)
        Me.POSD1.Name = "POSD1"
        Me.POSD1.ReadOnly = True
        Me.POSD1.Size = New System.Drawing.Size(73, 20)
        Me.POSD1.TabIndex = 6
        Me.POSD1.Text = "0"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(171, 21)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(71, 14)
        Me.Label14.TabIndex = 5
        Me.Label14.Text = "Motor Status:"
        '
        'STAT1
        '
        Me.STAT1.Location = New System.Drawing.Point(169, 44)
        Me.STAT1.Multiline = True
        Me.STAT1.Name = "STAT1"
        Me.STAT1.ReadOnly = True
        Me.STAT1.Size = New System.Drawing.Size(73, 46)
        Me.STAT1.TabIndex = 4
        Me.STAT1.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(39, 67)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 14)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Speed:"
        '
        'VX1
        '
        Me.VX1.Location = New System.Drawing.Point(86, 64)
        Me.VX1.Name = "VX1"
        Me.VX1.ReadOnly = True
        Me.VX1.Size = New System.Drawing.Size(73, 20)
        Me.VX1.TabIndex = 2
        Me.VX1.Text = "0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 14)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Enc Pos:"
        '
        'EX1
        '
        Me.EX1.Location = New System.Drawing.Point(86, 18)
        Me.EX1.Name = "EX1"
        Me.EX1.ReadOnly = True
        Me.EX1.Size = New System.Drawing.Size(73, 20)
        Me.EX1.TabIndex = 0
        Me.EX1.Text = "0"
        '
        'COMPort
        '
        Me.COMPort.Location = New System.Drawing.Point(15, 45)
        Me.COMPort.Name = "COMPort"
        Me.COMPort.Size = New System.Drawing.Size(49, 20)
        Me.COMPort.TabIndex = 47
        Me.COMPort.Text = "COM6"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(12, 28)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(52, 14)
        Me.Label32.TabIndex = 50
        Me.Label32.Text = "COM Port"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(34, 28)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(60, 14)
        Me.Label50.TabIndex = 61
        Me.Label50.Text = "Network ID"
        '
        'StartID
        '
        Me.StartID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.StartID.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StartID.FormattingEnabled = True
        Me.StartID.Items.AddRange(New Object() {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24"})
        Me.StartID.Location = New System.Drawing.Point(34, 45)
        Me.StartID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.StartID.Name = "StartID"
        Me.StartID.Size = New System.Drawing.Size(60, 22)
        Me.StartID.TabIndex = 60
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(31, 87)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(29, 14)
        Me.Label35.TabIndex = 79
        Me.Label35.Text = "RGB"
        '
        'BLed1
        '
        Me.BLed1.BackColor = System.Drawing.Color.LightGray
        Me.BLed1.Enabled = False
        Me.BLed1.Location = New System.Drawing.Point(107, 84)
        Me.BLed1.Name = "BLed1"
        Me.BLed1.Size = New System.Drawing.Size(20, 20)
        Me.BLed1.TabIndex = 78
        Me.BLed1.TabStop = False
        '
        'GLed1
        '
        Me.GLed1.BackColor = System.Drawing.Color.LightGray
        Me.GLed1.Enabled = False
        Me.GLed1.Location = New System.Drawing.Point(85, 84)
        Me.GLed1.Name = "GLed1"
        Me.GLed1.Size = New System.Drawing.Size(20, 20)
        Me.GLed1.TabIndex = 77
        Me.GLed1.TabStop = False
        '
        'RLed1
        '
        Me.RLed1.BackColor = System.Drawing.Color.LightGray
        Me.RLed1.Enabled = False
        Me.RLed1.Location = New System.Drawing.Point(63, 84)
        Me.RLed1.Name = "RLed1"
        Me.RLed1.Size = New System.Drawing.Size(20, 20)
        Me.RLed1.TabIndex = 76
        Me.RLed1.TabStop = False
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(35, 64)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(26, 14)
        Me.Label34.TabIndex = 75
        Me.Label34.Text = "LED"
        '
        'LEDStat1
        '
        Me.LEDStat1.BackColor = System.Drawing.Color.LightGray
        Me.LEDStat1.Enabled = False
        Me.LEDStat1.Location = New System.Drawing.Point(63, 63)
        Me.LEDStat1.Name = "LEDStat1"
        Me.LEDStat1.Size = New System.Drawing.Size(33, 18)
        Me.LEDStat1.TabIndex = 74
        Me.LEDStat1.TabStop = False
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(63, 16)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(127, 14)
        Me.Label33.TabIndex = 63
        Me.Label33.Text = "1   2    3   4   5    6   7   8 "
        '
        'DO13
        '
        Me.DO13.BackColor = System.Drawing.Color.Gainsboro
        Me.DO13.Location = New System.Drawing.Point(95, 42)
        Me.DO13.Name = "DO13"
        Me.DO13.Size = New System.Drawing.Size(10, 10)
        Me.DO13.TabIndex = 73
        Me.DO13.TabStop = False
        '
        'DO12
        '
        Me.DO12.BackColor = System.Drawing.Color.Gainsboro
        Me.DO12.Location = New System.Drawing.Point(79, 42)
        Me.DO12.Name = "DO12"
        Me.DO12.Size = New System.Drawing.Size(10, 10)
        Me.DO12.TabIndex = 72
        Me.DO12.TabStop = False
        '
        'DO11
        '
        Me.DO11.BackColor = System.Drawing.Color.Gainsboro
        Me.DO11.Location = New System.Drawing.Point(63, 42)
        Me.DO11.Name = "DO11"
        Me.DO11.Size = New System.Drawing.Size(10, 10)
        Me.DO11.TabIndex = 71
        Me.DO11.TabStop = False
        '
        'DI18
        '
        Me.DI18.BackColor = System.Drawing.Color.Gainsboro
        Me.DI18.Location = New System.Drawing.Point(175, 30)
        Me.DI18.Name = "DI18"
        Me.DI18.Size = New System.Drawing.Size(10, 10)
        Me.DI18.TabIndex = 70
        Me.DI18.TabStop = False
        '
        'DI17
        '
        Me.DI17.BackColor = System.Drawing.Color.Gainsboro
        Me.DI17.Location = New System.Drawing.Point(159, 30)
        Me.DI17.Name = "DI17"
        Me.DI17.Size = New System.Drawing.Size(10, 10)
        Me.DI17.TabIndex = 69
        Me.DI17.TabStop = False
        '
        'DI16
        '
        Me.DI16.BackColor = System.Drawing.Color.Gainsboro
        Me.DI16.Location = New System.Drawing.Point(143, 30)
        Me.DI16.Name = "DI16"
        Me.DI16.Size = New System.Drawing.Size(10, 10)
        Me.DI16.TabIndex = 68
        Me.DI16.TabStop = False
        '
        'DI15
        '
        Me.DI15.BackColor = System.Drawing.Color.Gainsboro
        Me.DI15.Location = New System.Drawing.Point(127, 30)
        Me.DI15.Name = "DI15"
        Me.DI15.Size = New System.Drawing.Size(10, 10)
        Me.DI15.TabIndex = 67
        Me.DI15.TabStop = False
        '
        'DI14
        '
        Me.DI14.BackColor = System.Drawing.Color.Gainsboro
        Me.DI14.Location = New System.Drawing.Point(111, 30)
        Me.DI14.Name = "DI14"
        Me.DI14.Size = New System.Drawing.Size(10, 10)
        Me.DI14.TabIndex = 66
        Me.DI14.TabStop = False
        '
        'DI13
        '
        Me.DI13.BackColor = System.Drawing.Color.Gainsboro
        Me.DI13.Location = New System.Drawing.Point(95, 30)
        Me.DI13.Name = "DI13"
        Me.DI13.Size = New System.Drawing.Size(10, 10)
        Me.DI13.TabIndex = 65
        Me.DI13.TabStop = False
        '
        'DI12
        '
        Me.DI12.BackColor = System.Drawing.Color.Gainsboro
        Me.DI12.Location = New System.Drawing.Point(79, 30)
        Me.DI12.Name = "DI12"
        Me.DI12.Size = New System.Drawing.Size(10, 10)
        Me.DI12.TabIndex = 64
        Me.DI12.TabStop = False
        '
        'DI11
        '
        Me.DI11.BackColor = System.Drawing.Color.Gainsboro
        Me.DI11.Location = New System.Drawing.Point(63, 30)
        Me.DI11.Name = "DI11"
        Me.DI11.Size = New System.Drawing.Size(10, 10)
        Me.DI11.TabIndex = 62
        Me.DI11.TabStop = False
        '
        'TextBox_TargetDecel
        '
        Me.TextBox_TargetDecel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_TargetDecel.Location = New System.Drawing.Point(66, 110)
        Me.TextBox_TargetDecel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox_TargetDecel.Name = "TextBox_TargetDecel"
        Me.TextBox_TargetDecel.Size = New System.Drawing.Size(78, 20)
        Me.TextBox_TargetDecel.TabIndex = 179
        Me.TextBox_TargetDecel.Text = "2000"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(29, 114)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(32, 12)
        Me.Label76.TabIndex = 185
        Me.Label76.Text = "Decel:"
        '
        'TextBox_TargetSpeed
        '
        Me.TextBox_TargetSpeed.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_TargetSpeed.Location = New System.Drawing.Point(66, 68)
        Me.TextBox_TargetSpeed.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox_TargetSpeed.Name = "TextBox_TargetSpeed"
        Me.TextBox_TargetSpeed.Size = New System.Drawing.Size(78, 20)
        Me.TextBox_TargetSpeed.TabIndex = 177
        Me.TextBox_TargetSpeed.Text = "100"
        '
        'TextBox_TargetAccel
        '
        Me.TextBox_TargetAccel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_TargetAccel.Location = New System.Drawing.Point(66, 89)
        Me.TextBox_TargetAccel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox_TargetAccel.Name = "TextBox_TargetAccel"
        Me.TextBox_TargetAccel.Size = New System.Drawing.Size(78, 20)
        Me.TextBox_TargetAccel.TabIndex = 178
        Me.TextBox_TargetAccel.Text = "2000"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(27, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 12)
        Me.Label1.TabIndex = 173
        Me.Label1.Text = "Speed:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(30, 93)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 12)
        Me.Label4.TabIndex = 174
        Me.Label4.Text = "Accel:"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(40, 40)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(40, 12)
        Me.Label68.TabIndex = 182
        Me.Label68.Text = "Homing:"
        '
        'ComboBox_HomeMode
        '
        Me.ComboBox_HomeMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_HomeMode.Font = New System.Drawing.Font("Arial Narrow", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_HomeMode.FormattingEnabled = True
        Me.ComboBox_HomeMode.Items.AddRange(New Object() {"0-Plus Home", "1-Neg Home", "2-Plus Lim", "3-Neg Lim", "4-Plus Home Index", "5-Neg Home Index", "6-Plus Lim Index", "7-Neg Lim Index", "8-Plus Index", "9-Neg Index"})
        Me.ComboBox_HomeMode.Location = New System.Drawing.Point(80, 35)
        Me.ComboBox_HomeMode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ComboBox_HomeMode.Name = "ComboBox_HomeMode"
        Me.ComboBox_HomeMode.Size = New System.Drawing.Size(68, 21)
        Me.ComboBox_HomeMode.TabIndex = 180
        '
        'Button_JogPlus
        '
        Me.Button_JogPlus.BackColor = System.Drawing.Color.White
        Me.Button_JogPlus.Enabled = False
        Me.Button_JogPlus.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_JogPlus.Location = New System.Drawing.Point(131, 31)
        Me.Button_JogPlus.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_JogPlus.Name = "Button_JogPlus"
        Me.Button_JogPlus.Size = New System.Drawing.Size(45, 25)
        Me.Button_JogPlus.TabIndex = 176
        Me.Button_JogPlus.Text = "J+"
        Me.Button_JogPlus.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button_JogPlus.UseVisualStyleBackColor = False
        '
        'Button_JogMinus
        '
        Me.Button_JogMinus.BackColor = System.Drawing.Color.White
        Me.Button_JogMinus.Enabled = False
        Me.Button_JogMinus.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_JogMinus.Location = New System.Drawing.Point(40, 31)
        Me.Button_JogMinus.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_JogMinus.Name = "Button_JogMinus"
        Me.Button_JogMinus.Size = New System.Drawing.Size(45, 25)
        Me.Button_JogMinus.TabIndex = 175
        Me.Button_JogMinus.Text = "J-"
        Me.Button_JogMinus.UseVisualStyleBackColor = False
        '
        'Button_Home
        '
        Me.Button_Home.BackColor = System.Drawing.Color.White
        Me.Button_Home.Enabled = False
        Me.Button_Home.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Home.Location = New System.Drawing.Point(80, 76)
        Me.Button_Home.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_Home.Name = "Button_Home"
        Me.Button_Home.Size = New System.Drawing.Size(68, 25)
        Me.Button_Home.TabIndex = 181
        Me.Button_Home.Text = "HOME"
        Me.Button_Home.UseVisualStyleBackColor = False
        '
        'ScurveRadio
        '
        Me.ScurveRadio.AutoSize = True
        Me.ScurveRadio.Checked = True
        Me.ScurveRadio.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ScurveRadio.Location = New System.Drawing.Point(77, 28)
        Me.ScurveRadio.Name = "ScurveRadio"
        Me.ScurveRadio.Size = New System.Drawing.Size(55, 16)
        Me.ScurveRadio.TabIndex = 188
        Me.ScurveRadio.TabStop = True
        Me.ScurveRadio.Text = "SCurve"
        Me.ScurveRadio.UseVisualStyleBackColor = True
        '
        'TrapRadio
        '
        Me.TrapRadio.AutoSize = True
        Me.TrapRadio.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TrapRadio.Location = New System.Drawing.Point(77, 45)
        Me.TrapRadio.Name = "TrapRadio"
        Me.TrapRadio.Size = New System.Drawing.Size(41, 16)
        Me.TrapRadio.TabIndex = 187
        Me.TrapRadio.Text = "Trap"
        Me.TrapRadio.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(28, 37)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(35, 12)
        Me.Label21.TabIndex = 186
        Me.Label21.Text = "Profile:"
        '
        'Button_X_Move1
        '
        Me.Button_X_Move1.BackColor = System.Drawing.Color.White
        Me.Button_X_Move1.Enabled = False
        Me.Button_X_Move1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_X_Move1.Location = New System.Drawing.Point(137, 24)
        Me.Button_X_Move1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_X_Move1.Name = "Button_X_Move1"
        Me.Button_X_Move1.Size = New System.Drawing.Size(33, 23)
        Me.Button_X_Move1.TabIndex = 197
        Me.Button_X_Move1.Text = "Go to Pos"
        Me.Button_X_Move1.UseVisualStyleBackColor = False
        '
        'TextBox_TargetPosition1
        '
        Me.TextBox_TargetPosition1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_TargetPosition1.Location = New System.Drawing.Point(74, 25)
        Me.TextBox_TargetPosition1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox_TargetPosition1.Name = "TextBox_TargetPosition1"
        Me.TextBox_TargetPosition1.Size = New System.Drawing.Size(56, 20)
        Me.TextBox_TargetPosition1.TabIndex = 193
        Me.TextBox_TargetPosition1.Text = "2500"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(42, 29)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(29, 12)
        Me.Label29.TabIndex = 190
        Me.Label29.Text = "Pos1:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.LEDStat1)
        Me.GroupBox1.Controls.Add(Me.DI11)
        Me.GroupBox1.Controls.Add(Me.DI12)
        Me.GroupBox1.Controls.Add(Me.DI13)
        Me.GroupBox1.Controls.Add(Me.DI14)
        Me.GroupBox1.Controls.Add(Me.DI15)
        Me.GroupBox1.Controls.Add(Me.DI16)
        Me.GroupBox1.Controls.Add(Me.DI17)
        Me.GroupBox1.Controls.Add(Me.DI18)
        Me.GroupBox1.Controls.Add(Me.DO11)
        Me.GroupBox1.Controls.Add(Me.DO12)
        Me.GroupBox1.Controls.Add(Me.DO13)
        Me.GroupBox1.Controls.Add(Me.Label33)
        Me.GroupBox1.Controls.Add(Me.Label34)
        Me.GroupBox1.Controls.Add(Me.RLed1)
        Me.GroupBox1.Controls.Add(Me.GLed1)
        Me.GroupBox1.Controls.Add(Me.BLed1)
        Me.GroupBox1.Controls.Add(Me.Label35)
        Me.GroupBox1.Location = New System.Drawing.Point(288, 97)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(213, 115)
        Me.GroupBox1.TabIndex = 200
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "DIO / LED / RGB"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(41, 42)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(22, 14)
        Me.Label6.TabIndex = 81
        Me.Label6.Text = "DO"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(41, 28)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(16, 14)
        Me.Label5.TabIndex = 80
        Me.Label5.Text = "DI"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.TabControl1)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.TextBox_TargetJerk)
        Me.GroupBox2.Controls.Add(Me.Button_STOPX)
        Me.GroupBox2.Controls.Add(Me.ScurveRadio)
        Me.GroupBox2.Controls.Add(Me.TrapRadio)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.TextBox_TargetAccel)
        Me.GroupBox2.Controls.Add(Me.TextBox_TargetSpeed)
        Me.GroupBox2.Controls.Add(Me.Label76)
        Me.GroupBox2.Controls.Add(Me.TextBox_TargetDecel)
        Me.GroupBox2.Location = New System.Drawing.Point(31, 218)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(470, 193)
        Me.GroupBox2.TabIndex = 201
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Motion"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.Servo)
        Me.TabControl1.Controls.Add(Me.TargetMotion)
        Me.TabControl1.Controls.Add(Me.JogMotion)
        Me.TabControl1.Controls.Add(Me.HomeMotion)
        Me.TabControl1.Controls.Add(Me.SA)
        Me.TabControl1.Location = New System.Drawing.Point(163, 24)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(224, 156)
        Me.TabControl1.TabIndex = 202
        '
        'Servo
        '
        Me.Servo.Controls.Add(Me.Button_ClearFault)
        Me.Servo.Controls.Add(Me.Button_Enable)
        Me.Servo.Controls.Add(Me.Button_Disable)
        Me.Servo.Location = New System.Drawing.Point(4, 23)
        Me.Servo.Name = "Servo"
        Me.Servo.Size = New System.Drawing.Size(216, 129)
        Me.Servo.TabIndex = 3
        Me.Servo.Text = "Servo"
        Me.Servo.UseVisualStyleBackColor = True
        '
        'Button_ClearFault
        '
        Me.Button_ClearFault.BackColor = System.Drawing.Color.White
        Me.Button_ClearFault.Enabled = False
        Me.Button_ClearFault.Font = New System.Drawing.Font("Arial", 7.8!)
        Me.Button_ClearFault.Location = New System.Drawing.Point(61, 70)
        Me.Button_ClearFault.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_ClearFault.Name = "Button_ClearFault"
        Me.Button_ClearFault.Size = New System.Drawing.Size(104, 27)
        Me.Button_ClearFault.TabIndex = 204
        Me.Button_ClearFault.Text = "Clear"
        Me.Button_ClearFault.UseVisualStyleBackColor = False
        '
        'Button_Enable
        '
        Me.Button_Enable.BackColor = System.Drawing.Color.White
        Me.Button_Enable.Enabled = False
        Me.Button_Enable.Font = New System.Drawing.Font("Arial", 7.8!)
        Me.Button_Enable.Location = New System.Drawing.Point(61, 28)
        Me.Button_Enable.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_Enable.Name = "Button_Enable"
        Me.Button_Enable.Size = New System.Drawing.Size(50, 27)
        Me.Button_Enable.TabIndex = 202
        Me.Button_Enable.Text = "SVON"
        Me.Button_Enable.UseVisualStyleBackColor = False
        '
        'Button_Disable
        '
        Me.Button_Disable.BackColor = System.Drawing.Color.White
        Me.Button_Disable.Enabled = False
        Me.Button_Disable.Font = New System.Drawing.Font("Arial", 7.8!)
        Me.Button_Disable.Location = New System.Drawing.Point(114, 28)
        Me.Button_Disable.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_Disable.Name = "Button_Disable"
        Me.Button_Disable.Size = New System.Drawing.Size(50, 27)
        Me.Button_Disable.TabIndex = 203
        Me.Button_Disable.Text = "SVOFF"
        Me.Button_Disable.UseVisualStyleBackColor = False
        '
        'TargetMotion
        '
        Me.TargetMotion.BackColor = System.Drawing.Color.White
        Me.TargetMotion.Controls.Add(Me.ButtonSetPos)
        Me.TargetMotion.Controls.Add(Me.Button_X_Move2)
        Me.TargetMotion.Controls.Add(Me.Label10)
        Me.TargetMotion.Controls.Add(Me.TextBox_TargetPosition2)
        Me.TargetMotion.Controls.Add(Me.Button_X_Move1)
        Me.TargetMotion.Controls.Add(Me.Label29)
        Me.TargetMotion.Controls.Add(Me.TextBox_TargetPosition1)
        Me.TargetMotion.Location = New System.Drawing.Point(4, 23)
        Me.TargetMotion.Name = "TargetMotion"
        Me.TargetMotion.Padding = New System.Windows.Forms.Padding(3)
        Me.TargetMotion.Size = New System.Drawing.Size(216, 129)
        Me.TargetMotion.TabIndex = 0
        Me.TargetMotion.Text = "Target"
        '
        'ButtonSetPos
        '
        Me.ButtonSetPos.BackColor = System.Drawing.Color.White
        Me.ButtonSetPos.Enabled = False
        Me.ButtonSetPos.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSetPos.Location = New System.Drawing.Point(74, 87)
        Me.ButtonSetPos.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ButtonSetPos.Name = "ButtonSetPos"
        Me.ButtonSetPos.Size = New System.Drawing.Size(56, 23)
        Me.ButtonSetPos.TabIndex = 201
        Me.ButtonSetPos.Text = "SetPos"
        Me.ButtonSetPos.UseVisualStyleBackColor = False
        '
        'Button_X_Move2
        '
        Me.Button_X_Move2.BackColor = System.Drawing.Color.White
        Me.Button_X_Move2.Enabled = False
        Me.Button_X_Move2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_X_Move2.Location = New System.Drawing.Point(137, 59)
        Me.Button_X_Move2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_X_Move2.Name = "Button_X_Move2"
        Me.Button_X_Move2.Size = New System.Drawing.Size(33, 23)
        Me.Button_X_Move2.TabIndex = 200
        Me.Button_X_Move2.Text = "Go to Pos"
        Me.Button_X_Move2.UseVisualStyleBackColor = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(42, 64)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(29, 12)
        Me.Label10.TabIndex = 198
        Me.Label10.Text = "Pos2:"
        '
        'TextBox_TargetPosition2
        '
        Me.TextBox_TargetPosition2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_TargetPosition2.Location = New System.Drawing.Point(74, 60)
        Me.TextBox_TargetPosition2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox_TargetPosition2.Name = "TextBox_TargetPosition2"
        Me.TextBox_TargetPosition2.Size = New System.Drawing.Size(56, 20)
        Me.TextBox_TargetPosition2.TabIndex = 199
        Me.TextBox_TargetPosition2.Text = "-2500"
        '
        'JogMotion
        '
        Me.JogMotion.BackColor = System.Drawing.Color.White
        Me.JogMotion.Controls.Add(Me.Button_ZeroVel)
        Me.JogMotion.Controls.Add(Me.JogVelBar)
        Me.JogMotion.Controls.Add(Me.Button_JogMinus)
        Me.JogMotion.Controls.Add(Me.Button_JogPlus)
        Me.JogMotion.Location = New System.Drawing.Point(4, 23)
        Me.JogMotion.Name = "JogMotion"
        Me.JogMotion.Padding = New System.Windows.Forms.Padding(3)
        Me.JogMotion.Size = New System.Drawing.Size(216, 129)
        Me.JogMotion.TabIndex = 1
        Me.JogMotion.Text = "Jog"
        '
        'Button_ZeroVel
        '
        Me.Button_ZeroVel.BackColor = System.Drawing.Color.White
        Me.Button_ZeroVel.Enabled = False
        Me.Button_ZeroVel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_ZeroVel.Location = New System.Drawing.Point(91, 31)
        Me.Button_ZeroVel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_ZeroVel.Name = "Button_ZeroVel"
        Me.Button_ZeroVel.Size = New System.Drawing.Size(34, 25)
        Me.Button_ZeroVel.TabIndex = 178
        Me.Button_ZeroVel.Text = "0"
        Me.Button_ZeroVel.UseVisualStyleBackColor = False
        '
        'JogVelBar
        '
        Me.JogVelBar.Enabled = False
        Me.JogVelBar.Location = New System.Drawing.Point(18, 73)
        Me.JogVelBar.Maximum = 200
        Me.JogVelBar.Name = "JogVelBar"
        Me.JogVelBar.Size = New System.Drawing.Size(180, 45)
        Me.JogVelBar.TabIndex = 177
        Me.JogVelBar.TickFrequency = 10
        Me.JogVelBar.Value = 100
        '
        'HomeMotion
        '
        Me.HomeMotion.BackColor = System.Drawing.Color.White
        Me.HomeMotion.Controls.Add(Me.ComboBox_HomeMode)
        Me.HomeMotion.Controls.Add(Me.Label68)
        Me.HomeMotion.Controls.Add(Me.Button_Home)
        Me.HomeMotion.Location = New System.Drawing.Point(4, 23)
        Me.HomeMotion.Name = "HomeMotion"
        Me.HomeMotion.Size = New System.Drawing.Size(216, 129)
        Me.HomeMotion.TabIndex = 2
        Me.HomeMotion.Text = "Home"
        '
        'SA
        '
        Me.SA.Controls.Add(Me.Label12)
        Me.SA.Controls.Add(Me.Label11)
        Me.SA.Controls.Add(Me.SubNumberList)
        Me.SA.Controls.Add(Me.Button_Gosub)
        Me.SA.Controls.Add(Me.Button_Stop2)
        Me.SA.Controls.Add(Me.Button_Stop1)
        Me.SA.Controls.Add(Me.Button_Run0)
        Me.SA.Controls.Add(Me.Button_Stop0)
        Me.SA.Controls.Add(Me.Button_Run1)
        Me.SA.Controls.Add(Me.Button_Run2)
        Me.SA.Location = New System.Drawing.Point(4, 23)
        Me.SA.Name = "SA"
        Me.SA.Size = New System.Drawing.Size(216, 129)
        Me.SA.TabIndex = 4
        Me.SA.Text = "SA"
        Me.SA.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(119, 65)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(34, 14)
        Me.Label12.TabIndex = 160
        Me.Label12.Text = "STOP"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(123, 23)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(28, 14)
        Me.Label11.TabIndex = 159
        Me.Label11.Text = "RUN"
        '
        'SubNumberList
        '
        Me.SubNumberList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SubNumberList.Font = New System.Drawing.Font("Arial", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SubNumberList.FormattingEnabled = True
        Me.SubNumberList.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32"})
        Me.SubNumberList.Location = New System.Drawing.Point(44, 46)
        Me.SubNumberList.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.SubNumberList.Name = "SubNumberList"
        Me.SubNumberList.Size = New System.Drawing.Size(49, 18)
        Me.SubNumberList.TabIndex = 158
        '
        'Button_Gosub
        '
        Me.Button_Gosub.BackColor = System.Drawing.Color.White
        Me.Button_Gosub.Enabled = False
        Me.Button_Gosub.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Gosub.Location = New System.Drawing.Point(44, 66)
        Me.Button_Gosub.Name = "Button_Gosub"
        Me.Button_Gosub.Size = New System.Drawing.Size(49, 22)
        Me.Button_Gosub.TabIndex = 157
        Me.Button_Gosub.Text = "Gosub"
        Me.Button_Gosub.UseVisualStyleBackColor = False
        '
        'Button_Stop2
        '
        Me.Button_Stop2.BackColor = System.Drawing.Color.White
        Me.Button_Stop2.Enabled = False
        Me.Button_Stop2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Stop2.Location = New System.Drawing.Point(147, 79)
        Me.Button_Stop2.Name = "Button_Stop2"
        Me.Button_Stop2.Size = New System.Drawing.Size(20, 20)
        Me.Button_Stop2.TabIndex = 150
        Me.Button_Stop2.Text = "2"
        Me.Button_Stop2.UseVisualStyleBackColor = False
        '
        'Button_Stop1
        '
        Me.Button_Stop1.BackColor = System.Drawing.Color.White
        Me.Button_Stop1.Enabled = False
        Me.Button_Stop1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Stop1.Location = New System.Drawing.Point(126, 79)
        Me.Button_Stop1.Name = "Button_Stop1"
        Me.Button_Stop1.Size = New System.Drawing.Size(20, 20)
        Me.Button_Stop1.TabIndex = 149
        Me.Button_Stop1.Text = "1"
        Me.Button_Stop1.UseVisualStyleBackColor = False
        '
        'Button_Run0
        '
        Me.Button_Run0.BackColor = System.Drawing.Color.White
        Me.Button_Run0.Enabled = False
        Me.Button_Run0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Run0.Location = New System.Drawing.Point(105, 37)
        Me.Button_Run0.Name = "Button_Run0"
        Me.Button_Run0.Size = New System.Drawing.Size(20, 20)
        Me.Button_Run0.TabIndex = 145
        Me.Button_Run0.Text = "0"
        Me.Button_Run0.UseVisualStyleBackColor = False
        '
        'Button_Stop0
        '
        Me.Button_Stop0.BackColor = System.Drawing.Color.White
        Me.Button_Stop0.Enabled = False
        Me.Button_Stop0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Stop0.Location = New System.Drawing.Point(105, 79)
        Me.Button_Stop0.Name = "Button_Stop0"
        Me.Button_Stop0.Size = New System.Drawing.Size(20, 20)
        Me.Button_Stop0.TabIndex = 148
        Me.Button_Stop0.Text = "0"
        Me.Button_Stop0.UseVisualStyleBackColor = False
        '
        'Button_Run1
        '
        Me.Button_Run1.BackColor = System.Drawing.Color.White
        Me.Button_Run1.Enabled = False
        Me.Button_Run1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Run1.Location = New System.Drawing.Point(126, 37)
        Me.Button_Run1.Name = "Button_Run1"
        Me.Button_Run1.Size = New System.Drawing.Size(20, 20)
        Me.Button_Run1.TabIndex = 146
        Me.Button_Run1.Text = "1"
        Me.Button_Run1.UseVisualStyleBackColor = False
        '
        'Button_Run2
        '
        Me.Button_Run2.BackColor = System.Drawing.Color.White
        Me.Button_Run2.Enabled = False
        Me.Button_Run2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Run2.Location = New System.Drawing.Point(147, 37)
        Me.Button_Run2.Name = "Button_Run2"
        Me.Button_Run2.Size = New System.Drawing.Size(20, 20)
        Me.Button_Run2.TabIndex = 147
        Me.Button_Run2.Text = "2"
        Me.Button_Run2.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(34, 135)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(26, 12)
        Me.Label9.TabIndex = 208
        Me.Label9.Text = "Jerk:"
        '
        'TextBox_TargetJerk
        '
        Me.TextBox_TargetJerk.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_TargetJerk.Location = New System.Drawing.Point(66, 131)
        Me.TextBox_TargetJerk.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox_TargetJerk.Name = "TextBox_TargetJerk"
        Me.TextBox_TargetJerk.Size = New System.Drawing.Size(78, 20)
        Me.TextBox_TargetJerk.TabIndex = 207
        Me.TextBox_TargetJerk.Text = "50000"
        '
        'Button_STOPX
        '
        Me.Button_STOPX.BackColor = System.Drawing.Color.White
        Me.Button_STOPX.Enabled = False
        Me.Button_STOPX.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_STOPX.Location = New System.Drawing.Point(403, 68)
        Me.Button_STOPX.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button_STOPX.Name = "Button_STOPX"
        Me.Button_STOPX.Size = New System.Drawing.Size(55, 83)
        Me.Button_STOPX.TabIndex = 206
        Me.Button_STOPX.Text = "STOP"
        Me.Button_STOPX.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button_STOPX.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.COMConnectBtn)
        Me.GroupBox3.Controls.Add(Me.COMPort)
        Me.GroupBox3.Controls.Add(Me.Label32)
        Me.GroupBox3.Location = New System.Drawing.Point(341, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(160, 78)
        Me.GroupBox3.TabIndex = 202
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "USB/Serial Communication"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label13)
        Me.GroupBox4.Controls.Add(Me.EthernetConnectBtn)
        Me.GroupBox4.Controls.Add(Me.IPAddress)
        Me.GroupBox4.Location = New System.Drawing.Point(122, 12)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(213, 78)
        Me.GroupBox4.TabIndex = 203
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Ethernet Communication"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(38, 28)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(59, 14)
        Me.Label13.TabIndex = 51
        Me.Label13.Text = "IP Address"
        '
        'EthernetConnectBtn
        '
        Me.EthernetConnectBtn.BackColor = System.Drawing.Color.Cyan
        Me.EthernetConnectBtn.Location = New System.Drawing.Point(125, 18)
        Me.EthernetConnectBtn.Name = "EthernetConnectBtn"
        Me.EthernetConnectBtn.Size = New System.Drawing.Size(75, 48)
        Me.EthernetConnectBtn.TabIndex = 1
        Me.EthernetConnectBtn.Text = "Connect"
        Me.EthernetConnectBtn.UseVisualStyleBackColor = False
        '
        'IPAddress
        '
        Me.IPAddress.Location = New System.Drawing.Point(15, 45)
        Me.IPAddress.Name = "IPAddress"
        Me.IPAddress.Size = New System.Drawing.Size(104, 20)
        Me.IPAddress.TabIndex = 47
        Me.IPAddress.Text = "192.168.1.100"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Controls.Add(Me.WriteVar)
        Me.GroupBox5.Controls.Add(Me.ReadVar)
        Me.GroupBox5.Controls.Add(Me.VarValue)
        Me.GroupBox5.Controls.Add(Me.VarIDList)
        Me.GroupBox5.Location = New System.Drawing.Point(31, 417)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(213, 60)
        Me.GroupBox5.TabIndex = 204
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Variable"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(80, 16)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(34, 14)
        Me.Label15.TabIndex = 181
        Me.Label15.Text = "Value"
        '
        'WriteVar
        '
        Me.WriteVar.Enabled = False
        Me.WriteVar.Location = New System.Drawing.Point(164, 29)
        Me.WriteVar.Name = "WriteVar"
        Me.WriteVar.Size = New System.Drawing.Size(35, 23)
        Me.WriteVar.TabIndex = 180
        Me.WriteVar.Text = "W"
        Me.WriteVar.UseVisualStyleBackColor = True
        '
        'ReadVar
        '
        Me.ReadVar.Enabled = False
        Me.ReadVar.Location = New System.Drawing.Point(127, 29)
        Me.ReadVar.Name = "ReadVar"
        Me.ReadVar.Size = New System.Drawing.Size(35, 23)
        Me.ReadVar.TabIndex = 179
        Me.ReadVar.Text = "R"
        Me.ReadVar.UseVisualStyleBackColor = True
        '
        'VarValue
        '
        Me.VarValue.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VarValue.Location = New System.Drawing.Point(75, 30)
        Me.VarValue.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.VarValue.Name = "VarValue"
        Me.VarValue.Size = New System.Drawing.Size(46, 20)
        Me.VarValue.TabIndex = 178
        Me.VarValue.Text = "0"
        '
        'VarIDList
        '
        Me.VarIDList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.VarIDList.FormattingEnabled = True
        Me.VarIDList.Items.AddRange(New Object() {"V1", "V2", "V3", "V4", "V5", "V6", "V7", "V8", "V9", "V10"})
        Me.VarIDList.Location = New System.Drawing.Point(18, 29)
        Me.VarIDList.Name = "VarIDList"
        Me.VarIDList.Size = New System.Drawing.Size(51, 22)
        Me.VarIDList.TabIndex = 0
        '
        'CommandTextbox
        '
        Me.CommandTextbox.Enabled = False
        Me.CommandTextbox.Location = New System.Drawing.Point(321, 450)
        Me.CommandTextbox.Name = "CommandTextbox"
        Me.CommandTextbox.Size = New System.Drawing.Size(168, 20)
        Me.CommandTextbox.TabIndex = 205
        '
        'ReplyTextbox
        '
        Me.ReplyTextbox.Location = New System.Drawing.Point(321, 427)
        Me.ReplyTextbox.Name = "ReplyTextbox"
        Me.ReplyTextbox.ReadOnly = True
        Me.ReplyTextbox.Size = New System.Drawing.Size(168, 20)
        Me.ReplyTextbox.TabIndex = 206
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(263, 453)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(57, 14)
        Me.Label16.TabIndex = 207
        Me.Label16.Text = "Command:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(284, 430)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(37, 14)
        Me.Label17.TabIndex = 208
        Me.Label17.Text = "Reply:"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(528, 498)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.ReplyTextbox)
        Me.Controls.Add(Me.CommandTextbox)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.StartID)
        Me.Controls.Add(Me.ID1GroupBox)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TITAN Sample Program"
        Me.ID1GroupBox.ResumeLayout(False)
        Me.ID1GroupBox.PerformLayout()
        CType(Me.BLed1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GLed1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RLed1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LEDStat1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DO13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DO12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DO11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DI18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DI17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DI16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DI15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DI14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DI13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DI12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DI11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.Servo.ResumeLayout(False)
        Me.TargetMotion.ResumeLayout(False)
        Me.TargetMotion.PerformLayout()
        Me.JogMotion.ResumeLayout(False)
        Me.JogMotion.PerformLayout()
        CType(Me.JogVelBar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.HomeMotion.ResumeLayout(False)
        Me.HomeMotion.PerformLayout()
        Me.SA.ResumeLayout(False)
        Me.SA.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents COMConnectBtn As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ID1GroupBox As GroupBox
    Friend WithEvents Label14 As Label
    Friend WithEvents STAT1 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents VX1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents EX1 As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents SASTAT1 As TextBox
    Friend WithEvents COMPort As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents StartID As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents VPROF1 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents POSD1 As TextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents BLed1 As PictureBox
    Friend WithEvents GLed1 As PictureBox
    Friend WithEvents RLed1 As PictureBox
    Friend WithEvents Label34 As Label
    Friend WithEvents LEDStat1 As PictureBox
    Friend WithEvents Label33 As Label
    Friend WithEvents DO13 As PictureBox
    Friend WithEvents DO12 As PictureBox
    Friend WithEvents DO11 As PictureBox
    Friend WithEvents DI18 As PictureBox
    Friend WithEvents DI17 As PictureBox
    Friend WithEvents DI16 As PictureBox
    Friend WithEvents DI15 As PictureBox
    Friend WithEvents DI14 As PictureBox
    Friend WithEvents DI13 As PictureBox
    Friend WithEvents DI12 As PictureBox
    Friend WithEvents DI11 As PictureBox
    Friend WithEvents TextBox_TargetDecel As TextBox
    Friend WithEvents Label76 As Label
    Friend WithEvents TextBox_TargetSpeed As TextBox
    Friend WithEvents TextBox_TargetAccel As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents ComboBox_HomeMode As ComboBox
    Friend WithEvents Button_JogPlus As Button
    Friend WithEvents Button_JogMinus As Button
    Friend WithEvents Button_Home As Button
    Friend WithEvents ScurveRadio As RadioButton
    Friend WithEvents TrapRadio As RadioButton
    Friend WithEvents Label21 As Label
    Friend WithEvents Button_X_Move1 As Button
    Friend WithEvents TextBox_TargetPosition1 As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Button_ClearFault As Button
    Friend WithEvents Button_Disable As Button
    Friend WithEvents Button_Enable As Button
    Friend WithEvents Button_STOPX As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBox_TargetJerk As TextBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents Servo As TabPage
    Friend WithEvents TargetMotion As TabPage
    Friend WithEvents Button_X_Move2 As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBox_TargetPosition2 As TextBox
    Friend WithEvents JogMotion As TabPage
    Friend WithEvents HomeMotion As TabPage
    Friend WithEvents JogVelBar As TrackBar
    Friend WithEvents Button_ZeroVel As Button
    Friend WithEvents ButtonSetPos As Button
    Friend WithEvents SA As TabPage
    Friend WithEvents SubNumberList As ComboBox
    Friend WithEvents Button_Gosub As Button
    Friend WithEvents Button_Stop2 As Button
    Friend WithEvents Button_Stop1 As Button
    Friend WithEvents Button_Run0 As Button
    Friend WithEvents Button_Stop0 As Button
    Friend WithEvents Button_Run1 As Button
    Friend WithEvents Button_Run2 As Button
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents EthernetConnectBtn As Button
    Friend WithEvents IPAddress As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label15 As Label
    Friend WithEvents WriteVar As Button
    Friend WithEvents ReadVar As Button
    Friend WithEvents VarValue As TextBox
    Friend WithEvents VarIDList As ComboBox
    Friend WithEvents CommandTextbox As TextBox
    Friend WithEvents ReplyTextbox As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
End Class
