﻿Public Class DEF_TITAN

    Public Shared COM_SERIAL As Integer = 0
    Public Shared COM_ETHERNET As Integer = 1

    Public Shared TCPClieantAvailableWaitTick As Long = 100000

    Public Shared SACStr As String = "SAC"
    Public Shared SAYStr As String = "SAY"
    Public Shared SASStr As String = "SAS"
    Public Shared SASM1Str As String = "SASM1"
    Public Shared SASM2Str As String = "SASM2"


    Public Shared ST_ENABLE As Integer = &H1
    Public Shared ST_IN_POSITION As Integer = &H2
    Public Shared ST_MOVING As Integer = &H4
    Public Shared ST_FAULT As Integer = &H8
    Public Shared ST_HOMING_COMP As Integer = &H10

    '*** Status Position Velocity Current Read
    Public Shared CURQA As String = "CURQA"     '***Actual Current A
    Public Shared CURDA As String = "CURDA"     '***Actual Current D
    Public Shared EX As String = "EX"           '***Actual Encoder Position
    Public Shared FLT As String = "FLT"         '***Get Fault Code
    Public Shared MST As String = "MST"         '***Motor Status
    Public Shared PERR As String = "PERR"       '***Position Error
    Public Shared POSD As String = "POSD"       '***Target Demand Position
    Public Shared VPROF As String = "VPROF"     '***Target Demand Profile Velocity
    Public Shared VX As String = "VX"           '***Actual Velocity based on Encoder Rate

    '*** Clear Error
    Public Shared ECLEARX As String = "ECLEARX" '***Clear Error

    '*** Lights
    Public Shared LED As String = "LED"         '***LED Light
    Public Shared RGB As String = "RGB"         '***RGB Light

    '*** Motion Stop
    Public Shared STOPX As String = "STOPX"     '***Stop Motion

    '*** Servo On Off Reset
    Public Shared SVOFF As String = "SVOFF"     '***Servo Off
    Public Shared SVON As String = "SVON"       '***Servo On
    Public Shared SVRST As String = "SVRST"     '***Reset Servo

    '*** Speed Accel Decel Jerk
    Public Shared ACC As String = "ACC"         '***Acceleration Rate
    Public Shared DEC As String = "DEC"         '***Deceleration Rate
    Public Shared HSPD As String = "HSPD"       '***Target Speed
    Public Shared JERK As String = "JERK"       '***Target Jerk
    Public Shared SCURVE As String = "SCURVE"   '***Set S Curve Profile
    Public Shared TRAP As String = "TRAP"       '***Set Trapezoidal Profile


    '*** Target Position
    Public Shared X As String = "X"             '***Perform Absolute Position Move

    '***Jogging
    Public Shared JOGXN As String = "JOGXN"     '***Jog in Negative Direction
    Public Shared JOGXP As String = "JOGXP"     '***Jog in Positive Direction

    '*** Homing
    Public Shared HMODE As String = "HMODE"     '***Homing Mode
    Public Shared HOMEX As String = "HOMEX"     '***Perform Home

    '*** Gains
    Public Shared CGAINF As String = "CGAINF"   '***Current Gain
    Public Shared IGAINF As String = "IGAINF"   '***Integeral Gain
    Public Shared PGAINF As String = "PGAINF"   '***Proportional Gain
    Public Shared VGAINF As String = "VGAINF"   '***Velocity Gain
    Public Shared KFCF As String = "KFCF"       '***Kalman Filter for Current
    Public Shared KFNF As String = "KFNF"       '***Kalman Filter for Position


    '*** Digital Inputs Outputs, Analog Input
    Public Shared DIN As String = "DIN"         '***Digital Input
    Public Shared DOA As String = "DOA"         '***Digital Output 1
    Public Shared DOB As String = "DOB"         '***Digital Output 2
    Public Shared DOC As String = "DOC"         '***Digital Output 3
    Public Shared DOUT As String = "DOUT"       '***Digital Output for all 3 bits
    Public Shared AIN As String = "AIN"         '***Analog Input Value

    Public Shared V As String = "V"             '***Variable

    Public Shared FIRMVS As String = "FIRMVS"   '***Firmware Version
    Public Shared MOTNAME As String = "MOTNAME" '***Motor Name
    Public Shared PWRV As String = "PWRV"       '***Power Input Voltage
    Public Shared PWRC As String = "PWRC"       '***Power Input Current
    Public Shared TEMP As String = "TEMP"       '***Temperature

    '*** A-Script Program Control
    Public Shared _GOSUB As String = "GOSUB"    '***Run Sub Routine
    Public Shared SAC As String = "SAC"         '***Standalone Program Control
    Public Shared SASM As String = "SASM"       '***Standalone Program Status

End Class
