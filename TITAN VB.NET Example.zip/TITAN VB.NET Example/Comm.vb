﻿Imports System.Net
Imports System.Threading
Imports System.Net.Sockets

Public Class Comm
    Public comType As Integer = DEF_TITAN.COM_SERIAL
    Public skiptimeout As Integer = 0
    Public read_try As Integer = 0
    Public comStat As Integer = 0

    Dim comPort As IO.Ports.SerialPort = New IO.Ports.SerialPort()
    Dim returnStr As String = ""

    Dim client As TcpClient
    Dim socketStat As Boolean = False

    Public Function Disconnect() As Boolean
        Try
            If (comType = DEF_TITAN.COM_SERIAL) Then
                comPort.Close()
            Else
                client.Close()
                client.Client.Dispose()
                socketStat = False
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Connect(typeNumber As Integer, port As String, reply_timeout As String) As Boolean
        Try
            comType = typeNumber
            If (comType = DEF_TITAN.COM_SERIAL) Then
                If comPort IsNot Nothing And comPort.IsOpen Then
                    comPort.Close()
                Else
                    comPort = New IO.Ports.SerialPort()
                    comPort.PortName = port
                    comPort.BaudRate = 115200
                    Dim tout As Integer
                    tout = reply_timeout
                    If (tout < 100) Then
                        tout = 100
                    ElseIf tout > 1000 Then
                        tout = 1000
                    End If
                    comPort.ReadTimeout = tout
                    comPort.Open()
                End If
            Else
                client = New TcpClient()
                client.Connect(IPAddress.Parse(port), 5000)
                Dim reply_timeout_val As Long

                If (IsNumeric(reply_timeout)) Then
                    reply_timeout_val = Long.Parse(reply_timeout)
                Else
                    reply_timeout_val = 100
                End If
                If (reply_timeout_val < 5) Then
                    reply_timeout_val = 5
                End If
                If (reply_timeout_val > 100) Then
                    reply_timeout_val = 100
                End If
                DEF_TITAN.TCPClieantAvailableWaitTick = 200000
                socketStat = True
            End If
            Return True
        Catch ex As Exception
            socketStat = False
            Return False
        End Try
    End Function

    Public ReadOnly Property IsConnected As Boolean
        Get
            If comType = DEF_TITAN.COM_SERIAL Then
                Return comPort IsNot Nothing And comPort.IsOpen
            Else
                Return socketStat
            End If
        End Get
    End Property

    Public Function Flush() As Boolean
        comPort.DiscardInBuffer()
        comPort.DiscardOutBuffer()
        Return True
    End Function

    Public Function Send(ByVal data As String) As Boolean
        Try
            If (comType = DEF_TITAN.COM_SERIAL) Then
                If comPort IsNot Nothing And comPort.IsOpen Then
                    comPort.WriteLine(data)
                    Dim myTime As DateTime = DateTime.Now
                End If
            Else
                data = data + Chr(13) + Chr(10)
                    Dim bytesToSend As Byte() = System.Text.Encoding.ASCII.GetBytes(data)
                    client.Client.Send(bytesToSend)
                End If
                Return True
            Catch ex As TimeoutException
                MsgBox("Write Timeout Error")
                comStat = -1
            Catch ex2 As Exception
                MsgBox("Communication Port Error")
            comStat = -2
        End Try
        Return False
    End Function

    Public Function Recv() As String
        Try
            If (comType = DEF_TITAN.COM_SERIAL) Then
                If comPort IsNot Nothing And comPort.IsOpen Then
                    Dim retstr As String
                    retstr = comPort.ReadLine()
                    read_try = 0
                    Return retstr
                Else
                    Return ""
                End If
            Else
                Dim counter As Long = 0
                Dim maxcounter As Long
                maxcounter = DEF_TITAN.TCPClieantAvailableWaitTick
                If (maxcounter < 50000) Then maxcounter = 50000
                If (maxcounter > 500000) Then maxcounter = 500000
                While (client.Available = 0)
                    If (counter > maxcounter) Then
                        Return ""
                    End If
                    counter = counter + 1
                End While
                If client.Available > 0 Then
                    Dim readBytes As Byte() = New Byte(client.Available - 1) {}
                    client.GetStream().Read(readBytes, 0, client.Available)
                    Dim str As String = System.Text.Encoding.ASCII.GetString(readBytes)
                    read_try = 0
                    Return str
                End If
            End If
            Return ""
        Catch ex As TimeoutException
            If (skiptimeout = 0) Then
                read_try = read_try + 1
                If (read_try > 2) Then
                    MsgBox("Read Timeout Error")
                    comStat = -3
                End If
            End If
        Catch ex2 As Exception
            MsgBox("Communication Port Error")
            comStat = -4
        End Try
        Return ""

    End Function

End Class
