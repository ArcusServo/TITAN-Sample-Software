﻿Imports System
Imports System.IO
Imports System.Globalization

Public Class TITAN_SerialCom
    Private Shared _instance As TITAN_SerialCom = Nothing
    Public ComStatus As Boolean
    Public PortStr As String
    Public netid As Integer
    Public comType As Integer = DEF_TITAN.COM_SERIAL
    Dim value() As String

    Private comm = New Comm()

    Public Function LED(stat As Integer) As Integer
        Try
            If (stat <> 0 And stat <> 1) Then
                Return -3
            End If
            comm.Send("@" + netid.ToString("00") + ":" +
                        DEF_TITAN.LED + "=" + stat.ToString)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                Return Integer.Parse(value(1)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply
        Catch ex As Exception
            Return -1 '***Exception
        End Try
    End Function
    Public Function DOBit(bit As Integer, stat As Integer) As Integer
        Try
            Dim cmdStr As String = DEF_TITAN.DOA
            If (bit = 0) Then
                cmdStr = DEF_TITAN.DOA
            ElseIf (bit = 1) Then
                cmdStr = DEF_TITAN.DOB
            ElseIf (bit = 2) Then
                cmdStr = DEF_TITAN.DOC
            Else
                Return -2
            End If
            If (stat <> 0 And stat <> 1) Then
                Return -3
            End If
            comm.Send("@" + netid.ToString("00") + ":" +
                        cmdStr + "=" + stat.ToString)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                Return Integer.Parse(value(1)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply
        Catch ex As Exception
            Return -1 '***Exception
        End Try
    End Function
    Public Function RGB(stat As Integer) As Integer
        Try
            If (stat < 0 Or stat > 7) Then
                Return -3
            End If
            comm.Send("@" + netid.ToString("00") + ":" +
                        DEF_TITAN.RGB + "=" + stat.ToString)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                Return Integer.Parse(value(1)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply
        Catch ex As Exception
            Return -1 '***Exception
        End Try
    End Function
    Public Function WRITE_VAR(ByRef vn As Integer, ByRef vval As Long) As Boolean
        Try
            If (vn < 1 Or vn > 100) Then
                Return False
            End If
            Dim strn As String
            strn = vn - 1

            comm.Send("@" + netid.ToString("00") + ":" + "V[" + strn + "]" + "=" + vval.ToString)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                vval = Long.Parse(value(1))
                Return True
            End If
            Return False
        Catch ex As Exception
            comm.Recv()
        End Try
        Return False
    End Function
    Public Function READ_VAR(ByRef vn As Integer, ByRef vval As Long) As Boolean
        Try
            If (vn < 1 Or vn > 100) Then
                Return False
            End If
            Dim strn As String
            strn = vn - 1

            comm.Send("@" + netid.ToString("00") + ":" + "V[" + strn + "]")
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                vval = Long.Parse(value(1))
                Return True
            End If
            Return False
        Catch ex As Exception
            comm.Recv()
        End Try
        Return False
    End Function

    Public Property EX() As Long
        Get
            Try
                comm.Send("@" + netid.ToString("00") + ":" +
                        DEF_TITAN.EX)
                Dim resp = comm.Recv()
                If resp.ToString.Length > 0 Then
                    value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                    Return Integer.Parse(value(1)) '*** Value of 1 - Success
                End If
                Return 0 '*** No reply
            Catch
                Return -1 '***Exception
            End Try
        End Get
        Set(ByVal value As Long)
            comm.Send("@" + netid.ToString("00") + ":" +
                        DEF_TITAN.EX + "=" + value.ToString)
            Dim resp = comm.Recv()
        End Set
    End Property
    Public Function SVON() As Integer
        Try
            comm.Send("@" + netid.ToString("00") + ":" + DEF_TITAN.SVON)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                Return Integer.Parse(value(1)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply

        Catch ex As Exception
            Return -1
        End Try
    End Function
    Public Function SVOFF() As Integer
        Try
            comm.Send("@" + netid.ToString("00") + ":" + DEF_TITAN.SVOFF)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                Return Integer.Parse(value(1)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply
        Catch ex As Exception
            Return -1
        End Try
    End Function
    Public Function ECLEARX() As Integer
        Try
            comm.Send("@" + netid.ToString("00") + ":" + DEF_TITAN.ECLEARX)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                Return Integer.Parse(value(1)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply
        Catch ex As Exception
            Return -1
        End Try
    End Function
    Public Function JOGXP(hspd As Double, accel As Double, decel As Double, jerk As Double, profile As Integer) As Integer
        Try
            Dim profileStr As String = DEF_TITAN.TRAP
            If (profile = 1) Then
                profileStr = DEF_TITAN.SCURVE
            End If
            comm.Send("@" + netid.ToString("00") + ":" +
                        DEF_TITAN.HSPD + "=" + hspd.ToString + ";" +
                        DEF_TITAN.ACC + "=" + accel.ToString + ";" +
                        DEF_TITAN.DEC + "=" + decel.ToString + ";" +
                        DEF_TITAN.JERK + "=" + jerk.ToString + ";" +
                        profileStr + ";" +
                        DEF_TITAN.JOGXP)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                Return Integer.Parse(value(11)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply
        Catch ex As Exception
            Return -1 '***Exception
        End Try
    End Function

    Public Function JOGXN(hspd As Double, accel As Double, decel As Double, jerk As Double, profile As Integer) As Integer
        Try
            Dim profileStr As String = DEF_TITAN.TRAP
            If (profile = 1) Then
                profileStr = DEF_TITAN.SCURVE
            End If
            comm.Send("@" + netid.ToString("00") + ":" +
                        DEF_TITAN.HSPD + "=" + hspd.ToString + ";" +
                        DEF_TITAN.ACC + "=" + accel.ToString + ";" +
                        DEF_TITAN.DEC + "=" + decel.ToString + ";" +
                        DEF_TITAN.JERK + "=" + jerk.ToString + ";" +
                        profileStr + ";" +
                        DEF_TITAN.JOGXN)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                Return Integer.Parse(value(11)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply
        Catch ex As Exception
            Return -1 '***Exception
        End Try
    End Function

    Public Function HOMEX(hmode As Integer, hspd As Double, accel As Double, decel As Double, jerk As Double, profile As Integer) As Integer
        Try
            Dim profileStr As String = DEF_TITAN.TRAP
            If (profile = 1) Then
                profileStr = DEF_TITAN.SCURVE
            End If
            comm.Send("@" + netid.ToString("00") + ":" +
                        "SVA" + "=" + hmode.ToString + ";" +
                        DEF_TITAN.HMODE + "=" + hmode.ToString + ";" +
                        DEF_TITAN.HSPD + "=" + hspd.ToString + ";" +
                        DEF_TITAN.ACC + "=" + accel.ToString + ";" +
                        DEF_TITAN.DEC + "=" + decel.ToString + ";" +
                        DEF_TITAN.JERK + "=" + jerk.ToString + ";" +
                        profileStr + ";" +
                        DEF_TITAN.HOMEX)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                'Return 1
                Return Integer.Parse(value(15)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply
        Catch ex As Exception
            Return -1 '***Exception
        End Try
    End Function

    Public Function X(target As Long, hspd As Double, accel As Double, decel As Double, jerk As Double, scurve As Integer) As Integer
        Try
            Dim profile As String = DEF_TITAN.TRAP
            If (scurve = 1) Then
                profile = DEF_TITAN.SCURVE
            End If

            comm.Send("@" + netid.ToString("00") + ":" +
                        DEF_TITAN.HSPD + "=" + hspd.ToString + ";" +
                        DEF_TITAN.ACC + "=" + accel.ToString + ";" +
                        DEF_TITAN.DEC + "=" + decel.ToString + ";" +
                        DEF_TITAN.JERK + "=" + jerk.ToString + ";" +
                        profile + ";" +
                        DEF_TITAN.X + "=" + target.ToString)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                Return Integer.Parse(value(11)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply
        Catch ex As Exception
            Return -1 '***Exception
        End Try
    End Function
    Public Function STOPX(hspd As Double, accel As Double, decel As Double) As Integer
        Try
            comm.Send("@" + netid.ToString("00") + ":" +
                        DEF_TITAN.HSPD + "=" + hspd.ToString + ";" +
                        DEF_TITAN.ACC + "=" + accel.ToString + ";" +
                        DEF_TITAN.DEC + "=" + decel.ToString + ";" +
                        DEF_TITAN.STOPX)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                Return Integer.Parse(value(7)) '*** Value of 1 - Success
            End If
            Return 0 '*** No reply
        Catch ex As Exception
            Return -1 '***Exception
        End Try
    End Function

    Public Function SCURVE() As Boolean
        Try
            comm.Send("@" + netid.ToString("00") + ":" + DEF_TITAN.SCURVE)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                Return True
            End If
            Return False '*** No reply
        Catch ex As Exception
            Return False '***Exception
        End Try
    End Function

    Public Function TRAP() As Boolean
        Try
            comm.Send("@" + netid.ToString("00") + ":" + DEF_TITAN.TRAP)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                Return True
            End If
            Return False '*** No reply
        Catch ex As Exception
            Return False '***Exception
        End Try
    End Function

    Public WriteOnly Property SA_COMMAND As Integer
        Set(value As Integer)
            Try
                comm.Send("@" + netid.ToString("00") + ":" + DEF_TITAN.SACStr + "=" + value.ToString)
                Dim resp = comm.Recv()
            Catch ex As Exception
            End Try
        End Set
    End Property
    Public Function ALLSTATUS(ByRef digital_input As Integer,
                                 ByRef digital_out As Integer,
                                 ByRef motor_stat As Integer,
                                 ByRef enc_pos As Long,
                                 ByRef enc_vel As Double,
                                 ByRef tar_pos As Long,
                                 ByRef tar_vel As Double,
                                 ByRef led_stat As Integer,
                                 ByRef rgb_stat As Integer) As Boolean

        Dim sendStr, resp As String
        sendStr = ""
        resp = ""
        Try
            sendStr = "@" + netid.ToString("00") + ":" + DEF_TITAN.DIN +
                                  ";" + DEF_TITAN.DOUT +
                                  ";" + DEF_TITAN.MST +
                                  ";" + DEF_TITAN.EX +
                                  ";" + DEF_TITAN.VX +
                                  ";" + DEF_TITAN.POSD +
                                  ";" + DEF_TITAN.VPROF +
                                  ";" + DEF_TITAN.LED +
                                  ";" + DEF_TITAN.RGB

            comm.Send(sendStr)
            resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                digital_input = CInt(value(1).Replace("0x", "&H"))
                digital_out = CInt(value(3).Replace("0x", "&H"))
                motor_stat = CInt(value(5).Replace("0x", "&H"))
                motor_stat = motor_stat
                enc_pos = Long.Parse(value(7))
                enc_vel = Double.Parse(value(9))
                tar_pos = Long.Parse(value(11))
                tar_vel = Double.Parse(value(13))
                led_stat = Integer.Parse(value(15))
                rgb_stat = Integer.Parse(value(17))
                Return True
            End If
        Catch ex As Exception
            comm.Recv()
        End Try
        Return False
    End Function
    Public ReadOnly Property SOFTWARE_VERSION As Double
        Get
            Try
                comm.Send("@" + netid.ToString("00") + ":" + DEF_TITAN.FIRMVS)
                Dim resp As String
                resp = comm.Recv()
                If resp.ToString.Length > 0 Then
                    value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                    Dim tempStr As String
                    tempStr = value(1)
                    Return Double.Parse(tempStr) / 100.0F
                End If
            Catch ex As Exception
                Dim resp = comm.Recv()
            End Try
            Return -1
        End Get
    End Property
    Public Function GOSUBCMD(n As Integer, ByRef retA As Long) As Boolean
        Try
            comm.Send("@" + netid.ToString("00") + ":" + "GOSUB=" + n.ToString)
            Dim resp = comm.Recv()
            If resp.ToString.Length > 0 Then
                value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                retA = Long.Parse(value(1))
            End If
            Return True
        Catch ex As Exception
            comm.Recv()
        End Try
        Return False
    End Function
    Public ReadOnly Property SAY As String
        Get
            Try
                comm.Send("@" + netid.ToString("00") + ":" + DEF_TITAN.SAYStr)
                Dim resp = comm.Recv()
                If resp.ToString.Length > 0 Then
                    value = resp.Split(New String() {"=", ";", vbCr}, StringSplitOptions.None)
                    Return value(1)
                End If
            Catch ex As Exception
            End Try
            Return 0
        End Get
    End Property
    Public Function CommandReply(ByRef cmdStr As String, ByRef replyStr As String) As Boolean
        Try
            comm.Send(cmdStr)
            Dim resp As String
            resp = comm.Recv()
            If (resp.Length > 0) Then
                replyStr = resp
                Return True
            Else
                replyStr = ""
                Return False
            End If
        Catch ex As Exception
            comm.Recv()
        End Try
        Return False
    End Function

    Public ReadOnly Property IsCommunicating As Boolean
        Get
            If comm.IsConnected = False Then
                Return False
            End If
            comm.skiptimeout = 1
            Dim str1 As String
            str1 = SOFTWARE_VERSION
            If SOFTWARE_VERSION > 0 Then
                ComStatus = True
                comm.skiptimeout = 0
                Return True
            End If
            ComStatus = False
            comm.skiptimeout = 0
            Return False
        End Get
    End Property
    Public Function Connect(port As String, reply_timeout As String) As Boolean
        If (comm.Connect(comType, port, reply_timeout) = True) Then
            PortStr = port
            Return True
        Else
            PortStr = "None"
            Return False
        End If
    End Function

    Public Function Disconnect() As Boolean
        ComStatus = False
        Return comm.Disconnect()
    End Function

    Public ReadOnly Property IsConnected As Boolean
        Get
            Return comm.IsConnected
        End Get
    End Property

    Public Shared ReadOnly Property Instance() As TITAN_SerialCom
        Get
            If _instance Is Nothing Then
                _instance = New TITAN_SerialCom()
            End If
            Return _instance
        End Get
    End Property
End Class

